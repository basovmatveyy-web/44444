<?php
require_once __DIR__ . '/../guard.php';
$user = $_SESSION['user'];
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>СХПК «Береговой» — Животноводство</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="../logo.png">
<link rel="stylesheet" href="../styles.css">
</head>
<body class="bg" data-role="<?=safe($user['role'] ?? '')?>">
<div id="bg-layer"></div><div id="bg-overlay"></div><div class="overlay"></div>

<header class="topbar">
  <div class="brand">
    <img src="../logo.png" class="logo" alt="">
    <span>СХПК «Береговой»</span>
  </div>
  <nav class="topnav">
    <a class="link" href="../modules.php">Разделы</a>
    <?php if (($user['role'] ?? '')==='admin'): ?>
      <a class="link" href="../admin.php">Админ‑панель</a>
    <?php endif; ?>
    <a class="link" href="../logout.php">Выход</a>
  </nav>
</header>

<main class="center-wrap">
  <section class="glass card-xl module-placeholder">
    <h1>Животноводство</h1>
    <p class="muted">Раздел подключен. Дальше здесь будем собирать учёт и отчёты по животным.</p>
    <div class="row gap">
      <a class="btn primary" href="../modules.php">Вернуться к разделам</a>
      <a class="btn" href="../dashboard.php">Перейти в растениеводство</a>
    </div>
  </section>
</main>

<footer class="foot muted sm">© <?=date('Y')?> СХПК «Береговой»</footer>
</body>
</html>
