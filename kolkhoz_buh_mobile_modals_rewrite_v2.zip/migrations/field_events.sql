-- История операций по участкам (полив/удобрения/посев/уборка)
-- Файл можно выполнить один раз в БД. В проекте также есть автосоздание таблиц
-- при добавлении записи (api_field_events.php).

CREATE TABLE IF NOT EXISTS field_waterings (
  id INT NOT NULL AUTO_INCREMENT,
  field_id INT NOT NULL,
  water_date DATE NOT NULL,
  amount VARCHAR(64) DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_field_date (field_id, water_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS field_fertilizations (
  id INT NOT NULL AUTO_INCREMENT,
  field_id INT NOT NULL,
  fert_date DATE NOT NULL,
  fertilizer VARCHAR(140) DEFAULT NULL,
  dose VARCHAR(80) DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_field_date (field_id, fert_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS field_sowings (
  id INT NOT NULL AUTO_INCREMENT,
  field_id INT NOT NULL,
  sow_date DATE NOT NULL,
  culture_id INT DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_field_date (field_id, sow_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS field_harvests (
  id INT NOT NULL AUTO_INCREMENT,
  field_id INT NOT NULL,
  harvest_date DATE NOT NULL,
  gross_yield VARCHAR(64) DEFAULT NULL,
  avg_yield VARCHAR(64) DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_field_date (field_id, harvest_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
