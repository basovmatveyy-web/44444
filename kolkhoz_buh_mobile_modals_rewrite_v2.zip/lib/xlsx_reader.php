<?php
/**
 * xlsx_reader.php — минимальный XLSX reader без зависимостей.
 *
 * Сделан максимально совместимым с «не свежим» PHP.
 * - нет typed properties (PHP 7.4+)
 * - нет строгих типов / return type hints
 * - не используется Throwable
 *
 * Требует расширения ext-zip (ZipArchive) и ext-simplexml.
 */

class XlsxReader
{
    /** @var string */
    private $path;

    /** @var ZipArchive */
    private $zip;

    /** @var array */
    private $sharedStrings = array();

    /** @var array sheetName => internal xml path */
    private $sheets = array();

    public static function open($path)
    {
        return new self($path);
    }

    private function __construct($path)
    {
        $this->path = $path;

        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('Расширение PHP ZipArchive (ext-zip) не установлено.');
        }
        if (!function_exists('simplexml_load_string')) {
            throw new RuntimeException('Расширение PHP SimpleXML (ext-simplexml) не установлено.');
        }

        $this->zip = new ZipArchive();
        $ok = $this->zip->open($this->path);
        if ($ok !== true) {
            throw new RuntimeException('Не удалось открыть XLSX');
        }

        $this->loadSharedStrings();
        $this->loadSheets();
    }

    public function close()
    {
        if ($this->zip) {
            @ $this->zip->close();
        }
    }

    public function sheetNames()
    {
        return array_keys($this->sheets);
    }

    /**
     * Read a sheet by name.
     * @return array<int, array<int, mixed>>
     */
    public function readSheet($name)
    {
        if (!isset($this->sheets[$name])) {
            throw new InvalidArgumentException('Лист не найден: ' . $name);
        }
        $xmlStr = $this->zipRead($this->sheets[$name]);
        if ($xmlStr === null || trim($xmlStr) === '') return array();

        $xml = @simplexml_load_string($xmlStr);
        if (!$xml) return array();

        $rowsXml = $xml->xpath('//*[local-name()="sheetData"]/*[local-name()="row"]');
        if (!$rowsXml) $rowsXml = array();

        $rawRows = array();
        $maxCol = 0;

        foreach ($rowsXml as $r) {
            $cells = $r->xpath('*[local-name()="c"]');
            if (!$cells) $cells = array();
            $row = array();
            foreach ($cells as $c) {
                $ref = isset($c['r']) ? (string)$c['r'] : '';
                if ($ref === '') continue;
                $colIdx0 = $this->colIndexFromRef($ref) - 1;
                if ($colIdx0 < 0) continue;
                $val = $this->parseCellValue($c);
                $row[$colIdx0] = $val;
                if ($colIdx0 + 1 > $maxCol) $maxCol = $colIdx0 + 1;
            }
            if (!empty($row)) {
                ksort($row);
            }
            $rawRows[] = $row;
        }

        // Normalize to dense matrix.
        $out = array();
        foreach ($rawRows as $row) {
            $dense = array();
            for ($i = 0; $i < $maxCol; $i++) $dense[$i] = null;
            foreach ($row as $i => $v) {
                $dense[(int)$i] = $v;
            }
            $out[] = $dense;
        }
        return $out;
    }

    /* ---------------- internal helpers ---------------- */

    private function zipRead($internalPath)
    {
        $p = ltrim($internalPath, '/');
        $idx = $this->zip->locateName($p);
        if ($idx === false) return null;
        $data = $this->zip->getFromIndex($idx);
        if ($data === false) return null;
        return $data;
    }

    private function loadSharedStrings()
    {
        $xmlStr = $this->zipRead('xl/sharedStrings.xml');
        if ($xmlStr === null || trim($xmlStr) === '') return;
        $xml = @simplexml_load_string($xmlStr);
        if (!$xml) return;

        $items = $xml->xpath('//*[local-name()="si"]');
        if (!$items) $items = array();

        foreach ($items as $si) {
            // shared strings can have multiple <t> pieces
            $ts = $si->xpath('.//*[local-name()="t"]');
            if (!$ts) {
                $this->sharedStrings[] = '';
                continue;
            }
            $parts = array();
            foreach ($ts as $t) $parts[] = (string)$t;
            $this->sharedStrings[] = implode('', $parts);
        }
    }

    private function loadSheets()
    {
        // Read workbook.xml to map sheet name -> sheetId/rId
        $wb = $this->zipRead('xl/workbook.xml');
        if ($wb === null) return;
        $wbXml = @simplexml_load_string($wb);
        if (!$wbXml) return;

        // Relationships: rId -> target
        $rels = array();
        $relsXmlStr = $this->zipRead('xl/_rels/workbook.xml.rels');
        if ($relsXmlStr !== null) {
            $relsXml = @simplexml_load_string($relsXmlStr);
            if ($relsXml) {
                $relNodes = $relsXml->xpath('//*[local-name()="Relationship"]');
                if (!$relNodes) $relNodes = array();
                foreach ($relNodes as $rel) {
                    $id = isset($rel['Id']) ? (string)$rel['Id'] : '';
                    $target = isset($rel['Target']) ? (string)$rel['Target'] : '';
                    if ($id && $target) {
                        $rels[$id] = $target;
                    }
                }
            }
        }

        $sheetNodes = $wbXml->xpath('//*[local-name()="sheet"]');
        if (!$sheetNodes) $sheetNodes = array();
        foreach ($sheetNodes as $sh) {
            $name = isset($sh['name']) ? (string)$sh['name'] : '';
            $rid = '';
            // r:id is namespaced; SimpleXML gives it as attribute with full name sometimes
            foreach ($sh->attributes() as $k => $v) {
                if ($k === 'id' || $k === 'r:id' || strpos($k, 'id') !== false) {
                    $rid = (string)$v;
                }
            }
            if ($name === '' || $rid === '') continue;
            if (!isset($rels[$rid])) continue;
            $target = $rels[$rid];
            // target is like "worksheets/sheet1.xml"
            $path = 'xl/' . ltrim($target, '/');
            $this->sheets[$name] = $path;
        }
    }

    private function parseCellValue($c)
    {
        $t = isset($c['t']) ? (string)$c['t'] : '';
        $vNodes = $c->xpath('*[local-name()="v"]');
        $v = ($vNodes && isset($vNodes[0])) ? (string)$vNodes[0] : '';

        if ($t === 's') {
            $idx = (int)$v;
            return isset($this->sharedStrings[$idx]) ? $this->sharedStrings[$idx] : '';
        }
        if ($t === 'b') {
            return ((string)$v === '1');
        }
        // default: number or plain string
        return ($v === '') ? null : $v;
    }

    private function colIndexFromRef($ref)
    {
        // e.g. "AB12" -> "AB"
        $letters = '';
        $len = strlen($ref);
        for ($i = 0; $i < $len; $i++) {
            $ch = $ref[$i];
            if ($ch >= 'A' && $ch <= 'Z') $letters .= $ch;
            else if ($ch >= 'a' && $ch <= 'z') $letters .= strtoupper($ch);
            else break;
        }
        if ($letters === '') return 1;

        $n = 0;
        $l = strlen($letters);
        for ($i = 0; $i < $l; $i++) {
            $n = $n * 26 + (ord($letters[$i]) - 64);
        }
        return $n;
    }
}
