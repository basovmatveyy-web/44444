<?php
$pageTitle = 'Бухгалтерия · Платежи';
$active = 'payments';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input id="paySearch" type="search" placeholder="Поиск по платежам (контрагент, назначение, №)" aria-label="Поиск по платежам">
    <select id="payStatus" data-ui="custom-select" aria-label="Статус">
      <option value="">Все статусы</option>
      <option value="draft">Черновик</option>
      <option value="approve">На согласовании</option>
      <option value="approved">Согласовано</option>
      <option value="paid">Оплачено</option>
      <option value="rejected">Отклонено</option>
    </select>
    <select id="payMethod" data-ui="custom-select" aria-label="Способ">
      <option value="">Все способы</option>
      <option value="bank">Банк</option>
      <option value="cash">Касса</option>
    </select>
    <input id="payFrom" type="date" aria-label="Дата с" style="max-width:180px">
    <input id="payTo" type="date" aria-label="Дата по" style="max-width:180px">
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Экспорт</a>
    <button id="btnAddPayment" class="btn primary sm" type="button">+ Заявка на оплату</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Реестр платежей">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Контрагент</th>
        <th>Статья</th>
        <th>Назначение</th>
        <th>Сумма</th>
        <th>Статус</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody id="tblPaymentsBody"></tbody>
  </table>
  <div id="payEmpty" class="buh-empty" hidden>Пока нет платежей. Нажмите «+ Заявка на оплату».</div>
</div>

<!-- Модалка: платёж -->
<div class="modal" id="modalPayment" hidden>
  <div class="glass modal-body">
    <h2 id="payModalTitle">Платёж</h2>
    <form class="form" id="formPayment" autocomplete="off">
      <input type="hidden" name="id" value="0">

      <label>Контрагент
        <select name="contractor_id" id="payContractor" data-ui="custom-select">
          <option value="">— не выбран —</option>
        </select>
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Договор
          <select name="contract_id" id="payContract" data-ui="custom-select">
            <option value="">— не выбран —</option>
          </select>
        </label>
        <label style="flex:1">Документ
          <select name="doc_id" id="payDoc" data-ui="custom-select">
            <option value="">— не выбран —</option>
          </select>
        </label>
      </div>

      <label>Статья ДДС
        <select name="dds_id" id="payDds" data-ui="custom-select">
          <option value="">— не выбрана —</option>
        </select>
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Дата оплаты
          <input type="date" name="pay_date">
        </label>
        <label style="flex:1">Сумма
          <input name="amount" inputmode="decimal" placeholder="0.00" required>
        </label>
      </div>

      <label>Назначение
        <input name="purpose" placeholder="Например: оплата по договору...">
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Статус
          <select name="status" data-ui="custom-select">
            <option value="draft">Черновик</option>
            <option value="approve">На согласовании</option>
            <option value="approved">Согласовано</option>
            <option value="paid">Оплачено</option>
            <option value="rejected">Отклонено</option>
          </select>
        </label>
        <label style="flex:1">Способ
          <select name="method" data-ui="custom-select">
            <option value="bank">Банк</option>
            <option value="cash">Касса</option>
          </select>
        </label>
      </div>

    </form>

    <div class="row gap modal-actions">
      <button class="btn primary" type="submit" form="formPayment">Сохранить</button>
      <button class="btn" type="button" data-close>Отмена</button>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
