<?php
$pageTitle = 'Бухгалтерия · Зарплата';
$active = 'salary';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input type="search" placeholder="Поиск по сотруднику (ФИО, табельный)" aria-label="Поиск по сотруднику">
    <select data-ui="select" aria-label="Период">
      <option value="">Текущий период</option>
      <option value="prev">Прошлый период</option>
      <option value="year">С начала года</option>
    </select>
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Экспорт</a>
    <button class="btn primary sm" type="button" disabled title="Скоро">+ Начисление</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Начисления и выплаты">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Сотрудник</th>
        <th>Период</th>
        <th>Начислено</th>
        <th>Удержано</th>
        <th>К выплате</th>
        <th>Статус</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Сотрудник">—</td>
        <td data-label="Период">—</td>
        <td data-label="Начислено">—</td>
        <td data-label="Удержано">—</td>
        <td data-label="К выплате">—</td>
        <td data-label="Статус"><span class="pill">Пусто</span></td>
      </tr>
    </tbody>
  </table>
  <div class="buh-empty">Здесь будет табель/начисления/выплата, реестры на банк и ведомости.</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
