<?php
$pageTitle = 'Бухгалтерия · Панель';
$active = 'dashboard';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <span class="pill">Панель бухгалтера</span>
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Отчёты</a>
    <a class="btn primary sm" href="payments.php">Платежи</a>
  </div>
</div>

<div class="buh-kpis" aria-label="Ключевые показатели">
  <div class="buh-kpi"><div id="kpiApprove" class="v">—</div><div class="l">На согласовании</div></div>
  <div class="buh-kpi"><div id="kpiOverdue" class="v">—</div><div class="l">Просрочено</div></div>
  <div class="buh-kpi"><div id="kpi7d" class="v">—</div><div class="l">К оплате (7 дней)</div></div>
  <div class="buh-kpi"><div id="kpiDocs" class="v">—</div><div class="l">Новые документы</div></div>
</div>

<div class="buh-toolbar" style="margin-top:16px">
  <div class="left">
    <h3 style="margin:0">Последние операции</h3>
    <span class="muted sm">Лента действий: документы, платежи, изменения.</span>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Лента операций">
  <table class="buh-table" aria-describedby="emptyOps">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Тип</th>
        <th>Описание</th>
        <th>Статус</th>
        <th>Кто</th>
      </tr>
    </thead>
    <tbody id="tblFeedBody"></tbody>
  </table>
  <div id="emptyOps" class="buh-empty" hidden>Пока нет операций.</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
