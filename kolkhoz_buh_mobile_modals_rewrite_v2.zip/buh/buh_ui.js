/* UI helpers for BUH module (custom selects etc.) */
(function(){
  'use strict';

  function closest(el, sel){
    while(el && el.nodeType===1){
      if (el.matches(sel)) return el;
      el = el.parentElement;
    }
    return null;
  }

  function enhanceSelect(native){
    if (!native || native.dataset.uiEnhanced==='1') return;
    native.dataset.uiEnhanced='1';

    var wrap = document.createElement('div');
    wrap.className = 'ui-select';
    native.parentNode.insertBefore(wrap, native);
    wrap.appendChild(native);

    native.classList.add('ui-select__native');
    native.setAttribute('aria-hidden','true');
    native.tabIndex = -1;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ui-select__btn';
    btn.setAttribute('aria-haspopup','listbox');
    btn.setAttribute('aria-expanded','false');
    btn.innerHTML = '<span class="ui-select__value"></span><span class="ui-select__chev" aria-hidden="true">▾</span>';

    var menu = document.createElement('div');
    menu.className = 'ui-select__menu';
    menu.setAttribute('role','listbox');

    wrap.appendChild(btn);
    wrap.appendChild(menu);

    function setBtnLabel(){
      var opt = native.options[native.selectedIndex];
      var v = opt ? opt.textContent : '';
      btn.querySelector('.ui-select__value').textContent = v;
    }

    function rebuild(){
      menu.innerHTML = '';
      Array.prototype.slice.call(native.options).forEach(function(opt){
        var item = document.createElement('button');
        item.type = 'button';
        item.className = 'ui-select__opt';
        item.textContent = opt.textContent;
        item.dataset.value = opt.value;
        item.disabled = !!opt.disabled;
        if (native.value === opt.value) item.classList.add('active');
        item.addEventListener('click', function(){
          if (item.disabled) return;
          native.value = item.dataset.value;
          // mark selected
          Array.prototype.slice.call(menu.querySelectorAll('.ui-select__opt')).forEach(function(x){ x.classList.remove('active'); });
          item.classList.add('active');
          setBtnLabel();
          close();
          native.dispatchEvent(new Event('change', {bubbles:true}));
        });
        menu.appendChild(item);
      });
      setBtnLabel();
    }

    function open(){
      // close others
      document.querySelectorAll('.ui-select.open').forEach(function(x){ if(x!==wrap){ x.classList.remove('open'); var b=x.querySelector('.ui-select__btn'); if(b) b.setAttribute('aria-expanded','false'); } });
      wrap.classList.add('open');
      btn.setAttribute('aria-expanded','true');
    }
    function close(){
      wrap.classList.remove('open');
      btn.setAttribute('aria-expanded','false');
    }
    function toggle(){
      if (wrap.classList.contains('open')) close(); else open();
    }

    btn.addEventListener('click', function(e){
      e.preventDefault();
      toggle();
    });

    btn.addEventListener('keydown', function(e){
      if (e.key==='Enter' || e.key===' '){
        e.preventDefault();
        toggle();
      }
      if (e.key==='Escape'){
        close();
      }
    });

    native.addEventListener('change', function(){
      rebuild();
    });

    document.addEventListener('click', function(e){
      if (!closest(e.target, '.ui-select') || closest(e.target, '.ui-select')!==wrap){
        close();
      }
    });

    rebuild();
  }

  function init(){
    document.querySelectorAll('select[data-ui="select"]').forEach(enhanceSelect);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
