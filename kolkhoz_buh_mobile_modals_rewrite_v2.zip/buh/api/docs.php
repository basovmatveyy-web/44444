<?php

declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');

$dirs = ['in','out'];
$types = ['invoice','act','waybill','upd','other'];
$statuses = ['draft','received','approved','paid','closed','rejected'];

if ($action === 'list') {
  $q = buh_req_str('q');
  $status = buh_req_str('status');
  $direction = buh_req_str('direction');
  $contractorId = buh_req_int('contractor_id');

  $sql = "SELECT d.id,d.direction,d.doc_type,d.number,d.doc_date,d.due_date,d.amount,d.status,
                 ct.name AS contractor_name,
                 c.number AS contract_number
          FROM buh_docs d
          LEFT JOIN buh_contractors ct ON ct.id=d.contractor_id
          LEFT JOIN buh_contracts c ON c.id=d.contract_id
          WHERE 1";
  $params = [];
  if ($status !== '') { $sql .= " AND d.status=?"; $params[]=$status; }
  if ($direction !== '') { $sql .= " AND d.direction=?"; $params[]=$direction; }
  if ($contractorId>0) { $sql .= " AND d.contractor_id=?"; $params[]=$contractorId; }
  if ($q !== '') {
    $sql .= " AND (d.number LIKE ? OR ct.name LIKE ? OR d.doc_type LIKE ?)";
    $like = "%$q%";
    array_push($params,$like,$like,$like);
  }
  $sql .= " ORDER BY IFNULL(d.doc_date,'9999-12-31') DESC, d.id DESC LIMIT 500";

  $st = $pdo->prepare($sql);
  $st->execute($params);
  json_ok(['items'=>$st->fetchAll()]);
}

if ($action === 'get') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  $st = $pdo->prepare("SELECT * FROM buh_docs WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch();
  if (!$row) json_err('Не найдено',404);
  json_ok(['item'=>$row]);
}

if ($action === 'save') {
  $id = buh_req_int('id');
  $direction = buh_enum(buh_req_str('direction','in'), $dirs, 'in');
  $docType = buh_enum(buh_req_str('doc_type','invoice'), $types, 'invoice');
  $status = buh_enum(buh_req_str('status','draft'), $statuses, 'draft');

  $data = [
    'direction' => $direction,
    'doc_type' => $docType,
    'contractor_id' => (buh_req_int('contractor_id')>0 ? buh_req_int('contractor_id') : null),
    'contract_id' => (buh_req_int('contract_id')>0 ? buh_req_int('contract_id') : null),
    'number' => null_if_empty(buh_req_str('number')),
    'doc_date' => null_if_empty(buh_req_str('doc_date')),
    'due_date' => null_if_empty(buh_req_str('due_date')),
    'amount' => null_if_empty(buh_req_str('amount')),
    'vat_amount' => null_if_empty(buh_req_str('vat_amount')),
    'status' => $status,
    'comment' => null_if_empty(buh_req_str('comment')),
  ];

  if ($id>0) {
    $st = $pdo->prepare("UPDATE buh_docs SET direction=:direction,doc_type=:doc_type,contractor_id=:contractor_id,contract_id=:contract_id,number=:number,doc_date=:doc_date,due_date=:due_date,amount=:amount,vat_amount=:vat_amount,status=:status,comment=:comment WHERE id=:id");
    $st->execute($data + ['id'=>$id]);
    buh_feed_add($pdo, 'doc', $id, 'Обновлён документ'.(empty($data['number'])?'':' №'.$data['number']), $status, (int)($_SESSION['user']['id'] ?? 0));
    json_ok(['id'=>$id]);
  }

  $st = $pdo->prepare("INSERT INTO buh_docs(direction,doc_type,contractor_id,contract_id,number,doc_date,due_date,amount,vat_amount,status,comment) VALUES(:direction,:doc_type,:contractor_id,:contract_id,:number,:doc_date,:due_date,:amount,:vat_amount,:status,:comment)");
  $st->execute($data);
  $newId = (int)$pdo->lastInsertId();
  buh_feed_add($pdo, 'doc', $newId, 'Добавлен документ'.(empty($data['number'])?'':' №'.$data['number']), $status, (int)($_SESSION['user']['id'] ?? 0));
  json_ok(['id'=>$newId]);
}

if ($action === 'delete') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  // если есть платежи — не удаляем
  $st = $pdo->prepare("SELECT COUNT(*) FROM buh_payments WHERE doc_id=?");
  $st->execute([$id]);
  if ((int)$st->fetchColumn() > 0) json_err('Нельзя удалить: есть платежи по документу');

  $pdo->prepare("DELETE FROM buh_docs WHERE id=?")->execute([$id]);
  buh_feed_add($pdo, 'doc', $id, 'Удалён документ', 'deleted', (int)($_SESSION['user']['id'] ?? 0));
  json_ok();
}

json_err('Неизвестное действие');
