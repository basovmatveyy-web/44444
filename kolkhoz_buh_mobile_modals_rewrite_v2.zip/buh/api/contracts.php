<?php

declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');

$statuses = ['active','closed','archive'];

if ($action === 'list') {
  $q = buh_req_str('q');
  $status = buh_req_str('status');
  $contractorId = buh_req_int('contractor_id');

  $sql = "SELECT c.id,c.number,c.doc_date,c.subject,c.amount,c.status,c.start_date,c.end_date,ct.name AS contractor_name,ct.id AS contractor_id
          FROM buh_contracts c
          JOIN buh_contractors ct ON ct.id=c.contractor_id
          WHERE 1";
  $params = [];
  if ($status !== '') { $sql .= " AND c.status=?"; $params[]=$status; }
  if ($contractorId>0) { $sql .= " AND c.contractor_id=?"; $params[]=$contractorId; }
  if ($q !== '') {
    $sql .= " AND (c.number LIKE ? OR c.subject LIKE ? OR ct.name LIKE ?)";
    $like = "%$q%";
    array_push($params,$like,$like,$like);
  }
  $sql .= " ORDER BY IFNULL(c.doc_date,'9999-12-31') DESC, c.id DESC LIMIT 500";

  $st = $pdo->prepare($sql);
  $st->execute($params);
  json_ok(['items'=>$st->fetchAll()]);
}

if ($action === 'get') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  $st = $pdo->prepare("SELECT * FROM buh_contracts WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch();
  if (!$row) json_err('Не найдено',404);
  json_ok(['item'=>$row]);
}

if ($action === 'save') {
  $id = buh_req_int('id');
  $contractorId = buh_req_int('contractor_id');
  if ($contractorId<=0) json_err('Контрагент обязателен');
  $number = buh_req_str('number');
  if ($number==='') json_err('Номер договора обязателен');
  $status = buh_enum(buh_req_str('status','active'), $statuses, 'active');

  $data = [
    'contractor_id' => $contractorId,
    'number' => $number,
    'doc_date' => null_if_empty(buh_req_str('doc_date')),
    'subject' => null_if_empty(buh_req_str('subject')),
    'amount' => null_if_empty(buh_req_str('amount')),
    'status' => $status,
    'start_date' => null_if_empty(buh_req_str('start_date')),
    'end_date' => null_if_empty(buh_req_str('end_date')),
    'comment' => null_if_empty(buh_req_str('comment')),
  ];

  if ($id>0) {
    $st = $pdo->prepare("UPDATE buh_contracts SET contractor_id=:contractor_id, number=:number, doc_date=:doc_date, subject=:subject, amount=:amount, status=:status, start_date=:start_date, end_date=:end_date, comment=:comment WHERE id=:id");
    $st->execute($data + ['id'=>$id]);
    buh_feed_add($pdo, 'contract', $id, 'Обновлён договор №'.$number, $status, (int)($_SESSION['user']['id'] ?? 0));
    json_ok(['id'=>$id]);
  }

  $st = $pdo->prepare("INSERT INTO buh_contracts(contractor_id,number,doc_date,subject,amount,status,start_date,end_date,comment) VALUES(:contractor_id,:number,:doc_date,:subject,:amount,:status,:start_date,:end_date,:comment)");
  $st->execute($data);
  $newId = (int)$pdo->lastInsertId();
  buh_feed_add($pdo, 'contract', $newId, 'Добавлен договор №'.$number, $status, (int)($_SESSION['user']['id'] ?? 0));
  json_ok(['id'=>$newId]);
}

if ($action === 'delete') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  // если есть документы/платежи — не удаляем
  $st = $pdo->prepare("SELECT COUNT(*) FROM buh_docs WHERE contract_id=?");
  $st->execute([$id]);
  if ((int)$st->fetchColumn() > 0) json_err('Нельзя удалить: есть документы по договору');

  $st2 = $pdo->prepare("SELECT COUNT(*) FROM buh_payments WHERE contract_id=?");
  $st2->execute([$id]);
  if ((int)$st2->fetchColumn() > 0) json_err('Нельзя удалить: есть платежи по договору');

  $pdo->prepare("DELETE FROM buh_contracts WHERE id=?")->execute([$id]);
  buh_feed_add($pdo, 'contract', $id, 'Удалён договор', 'deleted', (int)($_SESSION['user']['id'] ?? 0));
  json_ok();
}

json_err('Неизвестное действие');
