<?php

declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$action = (string)($_GET['action'] ?? 'dashboard');

if ($action === 'dashboard') {
  $k = [
    'payments_approve' => 0,
    'payments_overdue' => 0,
    'pay_7d_sum' => 0,
    'new_docs' => 0,
    'contractors' => 0,
    'contracts_active' => 0,
  ];

  try {
    $k['contractors'] = (int)$pdo->query("SELECT COUNT(*) FROM buh_contractors")->fetchColumn();
    $k['contracts_active'] = (int)$pdo->query("SELECT COUNT(*) FROM buh_contracts WHERE status='active'")->fetchColumn();
    $k['payments_approve'] = (int)$pdo->query("SELECT COUNT(*) FROM buh_payments WHERE status='approve'")->fetchColumn();

    // просрочка: pay_date < today и не paid
    $st = $pdo->prepare("SELECT COUNT(*) FROM buh_payments WHERE status IN ('draft','approve','approved') AND pay_date IS NOT NULL AND pay_date < CURDATE()");
    $st->execute();
    $k['payments_overdue'] = (int)$st->fetchColumn();

    // к оплате 7 дней: pay_date between today and today+7 and status in draft/approve
    $st2 = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM buh_payments WHERE status IN ('draft','approve','approved') AND pay_date IS NOT NULL AND pay_date >= CURDATE() AND pay_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)");
    $st2->execute();
    $k['pay_7d_sum'] = (float)$st2->fetchColumn();

    $st3 = $pdo->prepare("SELECT COUNT(*) FROM buh_docs WHERE status IN ('received','draft') AND (doc_date IS NULL OR doc_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY))");
    $st3->execute();
    $k['new_docs'] = (int)$st3->fetchColumn();
  } catch (Throwable $e) {}

  json_ok(['kpi'=>$k]);
}

if ($action === 'feed') {
  $st = $pdo->prepare("SELECT f.id,f.created_at,f.entity,f.entity_id,f.title,f.status,u.username,u.surname,u.name
                       FROM buh_feed f
                       LEFT JOIN users u ON u.id=f.user_id
                       ORDER BY f.created_at DESC, f.id DESC
                       LIMIT 30");
  $st->execute();
  $items = $st->fetchAll();
  json_ok(['items'=>$items]);
}

json_err('Неизвестное действие');
