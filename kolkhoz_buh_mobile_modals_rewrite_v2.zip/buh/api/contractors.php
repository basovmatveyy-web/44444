<?php

declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');

$types = ['supplier','buyer','landlord','employee','other'];

if ($action === 'list') {
  $q = buh_req_str('q');
  $type = buh_req_str('type');

  $sql = "SELECT id,type,name,inn,phone,bank_name,bik,account,updated_at FROM buh_contractors WHERE 1";
  $params = [];
  if ($type !== '') {
    $sql .= " AND type=?";
    $params[] = $type;
  }
  if ($q !== '') {
    $sql .= " AND (name LIKE ? OR inn LIKE ? OR phone LIKE ?)";
    $like = "%$q%";
    array_push($params, $like, $like, $like);
  }
  $sql .= " ORDER BY name ASC, id DESC LIMIT 500";

  $st = $pdo->prepare($sql);
  $st->execute($params);
  $items = $st->fetchAll();
  json_ok(['items' => $items]);
}

if ($action === 'get') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  $st = $pdo->prepare("SELECT * FROM buh_contractors WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch();
  if (!$row) json_err('Не найдено',404);
  json_ok(['item' => $row]);
}

if ($action === 'save') {
  $id = buh_req_int('id');
  $type = buh_enum(buh_req_str('type','supplier'), $types, 'supplier');
  $name = buh_req_str('name');
  if ($name === '') json_err('Название/ФИО обязательно');

  $data = [
    'type' => $type,
    'name' => $name,
    'inn' => null_if_empty(buh_req_str('inn')),
    'kpp' => null_if_empty(buh_req_str('kpp')),
    'ogrn' => null_if_empty(buh_req_str('ogrn')),
    'bank_name' => null_if_empty(buh_req_str('bank_name')),
    'bik' => null_if_empty(buh_req_str('bik')),
    'account' => null_if_empty(buh_req_str('account')),
    'corr_account' => null_if_empty(buh_req_str('corr_account')),
    'phone' => null_if_empty(buh_req_str('phone')),
    'email' => null_if_empty(buh_req_str('email')),
    'address' => null_if_empty(buh_req_str('address')),
    'comment' => null_if_empty(buh_req_str('comment')),
  ];

  if ($id > 0) {
    $sql = "UPDATE buh_contractors SET type=:type,name=:name,inn=:inn,kpp=:kpp,ogrn=:ogrn,bank_name=:bank_name,bik=:bik,account=:account,corr_account=:corr_account,phone=:phone,email=:email,address=:address,comment=:comment WHERE id=:id";
    $st = $pdo->prepare($sql);
    $st->execute($data + ['id'=>$id]);
    buh_feed_add($pdo, 'contractor', $id, 'Обновлён контрагент: '.$name, 'updated', (int)($_SESSION['user']['id'] ?? 0));
    json_ok(['id'=>$id]);
  }

  $sql = "INSERT INTO buh_contractors(type,name,inn,kpp,ogrn,bank_name,bik,account,corr_account,phone,email,address,comment) VALUES(:type,:name,:inn,:kpp,:ogrn,:bank_name,:bik,:account,:corr_account,:phone,:email,:address,:comment)";
  $st = $pdo->prepare($sql);
  $st->execute($data);
  $newId = (int)$pdo->lastInsertId();
  buh_feed_add($pdo, 'contractor', $newId, 'Добавлен контрагент: '.$name, 'created', (int)($_SESSION['user']['id'] ?? 0));
  json_ok(['id'=>$newId]);
}

if ($action === 'delete') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  // Защита: если есть договоры — не удаляем
  $st = $pdo->prepare("SELECT COUNT(*) FROM buh_contracts WHERE contractor_id=?");
  $st->execute([$id]);
  $cnt = (int)$st->fetchColumn();
  if ($cnt>0) json_err('Нельзя удалить: есть договоры с этим контрагентом');

  $st2 = $pdo->prepare("DELETE FROM buh_contractors WHERE id=?");
  $st2->execute([$id]);
  buh_feed_add($pdo, 'contractor', $id, 'Удалён контрагент', 'deleted', (int)($_SESSION['user']['id'] ?? 0));
  json_ok();
}

json_err('Неизвестное действие');
