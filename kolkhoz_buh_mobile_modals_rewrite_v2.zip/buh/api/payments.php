<?php

declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');

$statuses = ['draft','approve','approved','paid','rejected'];
$methods = ['bank','cash'];

$userId = (int)($_SESSION['user']['id'] ?? 0);

if ($action === 'list') {
  $q = buh_req_str('q');
  $status = buh_req_str('status');
  $method = buh_req_str('method');
  $from = buh_req_str('from');
  $to = buh_req_str('to');

  $sql = "SELECT p.id,p.pay_date,p.amount,p.purpose,p.status,p.method,p.dds_id,
                 ct.name AS contractor_name,
                 dds.name AS dds_name
          FROM buh_payments p
          LEFT JOIN buh_contractors ct ON ct.id=p.contractor_id
          LEFT JOIN buh_dds dds ON dds.id=p.dds_id
          WHERE 1";
  $params = [];
  if ($status !== '') { $sql .= " AND p.status=?"; $params[]=$status; }
  if ($method !== '') { $sql .= " AND p.method=?"; $params[]=$method; }
  if ($from !== '') { $sql .= " AND p.pay_date>=?"; $params[]=$from; }
  if ($to !== '') { $sql .= " AND p.pay_date<=?"; $params[]=$to; }
  if ($q !== '') {
    $sql .= " AND (ct.name LIKE ? OR p.purpose LIKE ? OR p.id LIKE ?)";
    $like = "%$q%";
    array_push($params,$like,$like,$like);
  }
  $sql .= " ORDER BY IFNULL(p.pay_date,'9999-12-31') DESC, p.id DESC LIMIT 500";

  $st = $pdo->prepare($sql);
  $st->execute($params);
  json_ok(['items'=>$st->fetchAll()]);
}

if ($action === 'get') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');
  $st = $pdo->prepare("SELECT * FROM buh_payments WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch();
  if (!$row) json_err('Не найдено',404);
  json_ok(['item'=>$row]);
}

if ($action === 'save') {
  $id = buh_req_int('id');

  // Для роли buh — только черновики (после отправки на согласование редактирование через «Отозвать»)
  if ($role === 'buh') {
    if ($id > 0) {
      $st0 = $pdo->prepare("SELECT status FROM buh_payments WHERE id=? LIMIT 1");
      $st0->execute([$id]);
      $cur = (string)($st0->fetchColumn() ?: '');
      if ($cur !== 'draft') json_err('Редактировать можно только платежи в статусе «Черновик»');
    }
  }

  $status = buh_enum(buh_req_str('status','draft'), $statuses, 'draft');
  $method = buh_enum(buh_req_str('method','bank'), $methods, 'bank');

  // buh всегда сохраняет как draft
  if ($role === 'buh') $status = 'draft';

  $amountRaw = buh_req_str('amount');
  $amount = (float)str_replace([',',' '], ['.',''], $amountRaw);

  $data = [
    'pay_date' => null_if_empty(buh_req_str('pay_date')),
    'contractor_id' => (buh_req_int('contractor_id')>0 ? buh_req_int('contractor_id') : null),
    'contract_id' => (buh_req_int('contract_id')>0 ? buh_req_int('contract_id') : null),
    'doc_id' => (buh_req_int('doc_id')>0 ? buh_req_int('doc_id') : null),
    'dds_id' => (buh_req_int('dds_id')>0 ? buh_req_int('dds_id') : null),
    'amount' => $amount,
    'purpose' => null_if_empty(buh_req_str('purpose')),
    'status' => $status,
    'method' => $method,
  ];

  if ($id>0) {
    // пытаемся обновить с dds_id; если хостинг не дал ALTER — сделаем упрощённый UPDATE
    try {
      $st = $pdo->prepare("UPDATE buh_payments SET pay_date=:pay_date,contractor_id=:contractor_id,contract_id=:contract_id,doc_id=:doc_id,dds_id=:dds_id,amount=:amount,purpose=:purpose,status=:status,method=:method WHERE id=:id");
      $st->execute($data + ['id'=>$id]);
    } catch (Throwable $e) {
      $st = $pdo->prepare("UPDATE buh_payments SET pay_date=:pay_date,contractor_id=:contractor_id,contract_id=:contract_id,doc_id=:doc_id,amount=:amount,purpose=:purpose,status=:status,method=:method WHERE id=:id");
      $st->execute($data + ['id'=>$id]);
    }

    // timestamps для админа (если вручную поставили статус)
    if ($role === 'admin') {
      if ($status === 'approved') {
        try {
          $pdo->prepare("UPDATE buh_payments SET approved_by=?, approved_at=NOW() WHERE id=?")->execute([$userId,$id]);
        } catch (Throwable $e) {}
      }
      if ($status === 'paid') {
        try {
          $pdo->prepare("UPDATE buh_payments SET paid_at=NOW(), pay_date=COALESCE(pay_date, CURDATE()) WHERE id=?")->execute([$id]);
        } catch (Throwable $e) {}
      }
    }

    buh_feed_add($pdo, 'payment', $id, 'Обновлён платёж #'.$id, $status, $userId);
    json_ok(['id'=>$id]);
  }

  $data['created_by'] = $userId;

  try {
    $st = $pdo->prepare("INSERT INTO buh_payments(pay_date,contractor_id,contract_id,doc_id,dds_id,amount,purpose,status,method,created_by) VALUES(:pay_date,:contractor_id,:contract_id,:doc_id,:dds_id,:amount,:purpose,:status,:method,:created_by)");
    $st->execute($data);
  } catch (Throwable $e) {
    // fallback без dds_id
    $st = $pdo->prepare("INSERT INTO buh_payments(pay_date,contractor_id,contract_id,doc_id,amount,purpose,status,method,created_by) VALUES(:pay_date,:contractor_id,:contract_id,:doc_id,:amount,:purpose,:status,:method,:created_by)");
    $st->execute($data);
  }

  $newId = (int)$pdo->lastInsertId();
  buh_feed_add($pdo, 'payment', $newId, 'Добавлен платёж #'.$newId, $status, $userId);
  json_ok(['id'=>$newId]);
}

if ($action === 'transition') {
  $id = buh_req_int('id');
  $to = buh_req_str('to');
  if ($id<=0) json_err('id обязателен');
  if (!in_array($to, $statuses, true)) json_err('Неверный статус');

  $st = $pdo->prepare("SELECT id,status,pay_date FROM buh_payments WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch();
  if (!$row) json_err('Не найдено', 404);
  $from = (string)$row['status'];

  $allowed = false;
  $title = '';

  if ($role === 'buh') {
    if ($from === 'draft' && $to === 'approve') { $allowed = true; $title = 'Отправлен на согласование платёж #'.$id; }
    if ($from === 'approve' && $to === 'draft') { $allowed = true; $title = 'Отозван в черновик платёж #'.$id; }
    if ($from === 'rejected' && $to === 'draft') { $allowed = true; $title = 'Возврат в черновик (после отклонения) платёж #'.$id; }
  }

  if ($role === 'admin') {
    if ($from === 'approve' && in_array($to, ['approved','rejected'], true)) {
      $allowed = true;
      $title = ($to==='approved' ? 'Согласован платёж #'.$id : 'Отклонён платёж #'.$id);
    }
    if ($from === 'approved' && $to === 'paid') {
      $allowed = true;
      $title = 'Отмечен как оплаченный платёж #'.$id;
    }
    if ($from === 'rejected' && $to === 'draft') {
      $allowed = true;
      $title = 'Возврат отклонённого платежа в черновик #'.$id;
    }
  }

  if (!$allowed) json_err('Переход недоступен');

  // Пытаемся сделать расширенный UPDATE, при ошибке (нет колонки) — упрощённый.
  try {
    if ($to === 'approved') {
      $pdo->prepare("UPDATE buh_payments SET status=?, approved_by=?, approved_at=NOW() WHERE id=?")->execute([$to, $userId, $id]);
    } elseif ($to === 'paid') {
      $pdo->prepare("UPDATE buh_payments SET status=?, paid_at=NOW(), pay_date=COALESCE(pay_date, CURDATE()) WHERE id=?")->execute([$to, $id]);
    } else {
      $pdo->prepare("UPDATE buh_payments SET status=? WHERE id=?")->execute([$to, $id]);
    }
  } catch (Throwable $e) {
    $pdo->prepare("UPDATE buh_payments SET status=? WHERE id=?")->execute([$to, $id]);
  }

  buh_feed_add($pdo, 'payment', $id, $title, $to, $userId);
  json_ok(['from'=>$from,'to'=>$to]);
}

if ($action === 'delete') {
  $id = buh_req_int('id');
  if ($id<=0) json_err('id обязателен');

  if ($role === 'buh') {
    // buh может удалять только черновики
    $st0 = $pdo->prepare("SELECT status FROM buh_payments WHERE id=? LIMIT 1");
    $st0->execute([$id]);
    $cur = (string)($st0->fetchColumn() ?: '');
    if ($cur !== 'draft') json_err('Удалять можно только черновики');
  }

  $pdo->prepare("DELETE FROM buh_payments WHERE id=?")->execute([$id]);
  buh_feed_add($pdo, 'payment', $id, 'Удалён платёж', 'deleted', $userId);
  json_ok();
}

json_err('Неизвестное действие');
