<?php

declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');
$kinds = ['in','out'];

if ($action === 'list') {
  $q = buh_req_str('q');
  $kind = buh_req_str('kind');

  $sql = "SELECT id,kind,name,comment FROM buh_dds WHERE 1";
  $params = [];
  if ($kind !== '') { $sql .= " AND kind=?"; $params[] = $kind; }
  if ($q !== '') {
    $sql .= " AND (name LIKE ? OR comment LIKE ?)";
    $like = "%" . $q . "%";
    array_push($params, $like, $like);
  }
  $sql .= " ORDER BY kind ASC, name ASC, id DESC LIMIT 1000";

  $st = $pdo->prepare($sql);
  $st->execute($params);
  json_ok(['items' => $st->fetchAll()]);
}

if ($action === 'get') {
  $id = buh_req_int('id');
  if ($id <= 0) json_err('id обязателен');
  $st = $pdo->prepare("SELECT * FROM buh_dds WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch();
  if (!$row) json_err('Не найдено', 404);
  json_ok(['item' => $row]);
}

if ($action === 'save') {
  $id = buh_req_int('id');
  $kind = buh_enum(buh_req_str('kind','out'), $kinds, 'out');
  $name = buh_req_str('name');
  if ($name === '') json_err('Название обязательно');

  $data = [
    'kind' => $kind,
    'name' => $name,
    'comment' => null_if_empty(buh_req_str('comment')),
  ];

  if ($id > 0) {
    $st = $pdo->prepare("UPDATE buh_dds SET kind=:kind,name=:name,comment=:comment WHERE id=:id");
    $st->execute($data + ['id' => $id]);
    buh_feed_add($pdo, 'dds', $id, 'Обновлена статья ДДС: ' . $name, $kind, (int)($_SESSION['user']['id'] ?? 0));
    json_ok(['id' => $id]);
  }

  $st = $pdo->prepare("INSERT INTO buh_dds(kind,name,comment) VALUES(:kind,:name,:comment)");
  $st->execute($data);
  $newId = (int)$pdo->lastInsertId();
  buh_feed_add($pdo, 'dds', $newId, 'Добавлена статья ДДС: ' . $name, $kind, (int)($_SESSION['user']['id'] ?? 0));
  json_ok(['id' => $newId]);
}

if ($action === 'delete') {
  $id = buh_req_int('id');
  if ($id <= 0) json_err('id обязателен');

  // если статья используется в платежах — не удаляем
  try {
    $st = $pdo->prepare("SELECT COUNT(*) FROM buh_payments WHERE dds_id=?");
    $st->execute([$id]);
    if ((int)$st->fetchColumn() > 0) json_err('Нельзя удалить: статья используется в платежах');
  } catch (Throwable $e) {
    // ignore
  }

  $pdo->prepare("DELETE FROM buh_dds WHERE id=?")->execute([$id]);
  buh_feed_add($pdo, 'dds', $id, 'Удалена статья ДДС', 'deleted', (int)($_SESSION['user']['id'] ?? 0));
  json_ok();
}

json_err('Неизвестное действие');
