<?php

declare(strict_types=1);

require_once __DIR__ . '/../../api_common.php';
require_user();

$role = (string)($_SESSION['user']['role'] ?? 'user');
if (!in_array($role, ['admin','buh'], true)) {
  json_err('Нет доступа', 403);
}

$pdo = pdo();
require_once __DIR__ . '/../buh_db.php';
buh_migrate($pdo);

// CSRF проверяем для всех не-GET запросов
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'GET') {
  $token = (string)($_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
  check_csrf_or_die($token);
}

function buh_req_int(string $k, int $default=0): int {
  $v = $_POST[$k] ?? $_GET[$k] ?? $default;
  return (int)$v;
}

function buh_req_str(string $k, string $default=''): string {
  return trim((string)($_POST[$k] ?? $_GET[$k] ?? $default));
}

function buh_enum(string $v, array $allowed, string $fallback): string {
  return in_array($v, $allowed, true) ? $v : $fallback;
}

