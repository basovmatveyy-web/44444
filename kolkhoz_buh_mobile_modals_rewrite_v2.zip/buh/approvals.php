<?php
$pageTitle = 'Бухгалтерия · Согласования';
$active = 'approvals';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input id="apprSearch" type="search" placeholder="Поиск (контрагент, назначение, №)" aria-label="Поиск по согласованиям">
    <select id="apprStatus" data-ui="custom-select" aria-label="Статус">
      <option value="approve">Ожидает согласования</option>
      <option value="">Все</option>
      <option value="approved">Согласовано</option>
      <option value="rejected">Отклонено</option>
    </select>
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Экспорт</a>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Очередь согласований">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Контрагент</th>
        <th>Статья</th>
        <th>Назначение</th>
        <th>Сумма</th>
        <th>Статус</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody id="tblApprovalsBody"></tbody>
  </table>
  <div id="apprEmpty" class="buh-empty" hidden>Пока нет заявок на согласование.</div>
  <div class="buh-empty muted sm" style="border-top:1px solid rgba(255,255,255,.06)">Сейчас в согласованиях: заявки на оплату. Документы добавим следующими итерациями.</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
