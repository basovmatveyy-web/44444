<?php

declare(strict_types=1);

require_once __DIR__ . '/guard_buh.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/buh_db.php';

// $pdo из config.php
if (!isset($pdo) || !$pdo instanceof PDO) {
  http_response_code(500);
  echo 'DB connection not found';
  exit;
}

buh_migrate($pdo);

$type = (string)($_GET['type'] ?? 'pay_reg');
$from = (string)($_GET['from'] ?? '');
$to = (string)($_GET['to'] ?? '');

$allowedTypes = ['pay_reg','docs_reg','contracts_reg','contractors_debt'];
if (!in_array($type, $allowedTypes, true)) {
  http_response_code(400);
  echo 'Bad type';
  exit;
}

function add_date_filter(string &$sql, array &$params, string $field, string $from, string $to): void {
  if ($from !== '') { $sql .= " AND $field >= ?"; $params[] = $from; }
  if ($to !== '') { $sql .= " AND $field <= ?"; $params[] = $to; }
}

$cols = [];
$rows = [];
$params = [];

try {
  if ($type === 'pay_reg') {
    $cols = ['ID','Дата','Контрагент','Статья','Назначение','Сумма','Статус','Способ'];
    $sql = "SELECT p.id,p.pay_date,ct.name AS contractor,dds.name AS dds,p.purpose,p.amount,p.status,p.method
            FROM buh_payments p
            LEFT JOIN buh_contractors ct ON ct.id=p.contractor_id
            LEFT JOIN buh_dds dds ON dds.id=p.dds_id
            WHERE 1";
    add_date_filter($sql, $params, 'p.pay_date', $from, $to);
    $sql .= " ORDER BY IFNULL(p.pay_date,'9999-12-31') DESC, p.id DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
      $rows[] = [(string)$r['id'], (string)($r['pay_date']??''), (string)($r['contractor']??''), (string)($r['dds']??''), (string)($r['purpose']??''), (string)($r['amount']??''), (string)($r['status']??''), (string)($r['method']??'')];
    }
  }

  if ($type === 'docs_reg') {
    $cols = ['ID','Дата','Тип','Контрагент','Номер','Срок оплаты','Сумма','Статус'];
    $sql = "SELECT d.id,d.doc_date,d.direction,d.doc_type,ct.name AS contractor,d.number,d.due_date,d.amount,d.status
            FROM buh_docs d
            LEFT JOIN buh_contractors ct ON ct.id=d.contractor_id
            WHERE 1";
    add_date_filter($sql, $params, 'd.doc_date', $from, $to);
    $sql .= " ORDER BY IFNULL(d.doc_date,'9999-12-31') DESC, d.id DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
      $typeLabel = ((string)$r['direction']==='out' ? 'Исх. ' : 'Вх. ') . (string)($r['doc_type'] ?? '');
      $rows[] = [(string)$r['id'], (string)($r['doc_date']??''), $typeLabel, (string)($r['contractor']??''), (string)($r['number']??''), (string)($r['due_date']??''), (string)($r['amount']??''), (string)($r['status']??'')];
    }
  }

  if ($type === 'contracts_reg') {
    $cols = ['ID','Дата','Контрагент','Номер','Предмет','Сумма','Статус'];
    $sql = "SELECT c.id,c.doc_date,ct.name AS contractor,c.number,c.subject,c.amount,c.status
            FROM buh_contracts c
            JOIN buh_contractors ct ON ct.id=c.contractor_id
            WHERE 1";
    add_date_filter($sql, $params, 'c.doc_date', $from, $to);
    $sql .= " ORDER BY IFNULL(c.doc_date,'9999-12-31') DESC, c.id DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
      $rows[] = [(string)$r['id'], (string)($r['doc_date']??''), (string)($r['contractor']??''), (string)($r['number']??''), (string)($r['subject']??''), (string)($r['amount']??''), (string)($r['status']??'')];
    }
  }

  if ($type === 'contractors_debt') {
    $cols = ['Контрагент','Кол-во заявок','Сумма к оплате','Ближайшая дата'];
    $sql = "SELECT ct.name AS contractor, COUNT(p.id) AS cnt, COALESCE(SUM(p.amount),0) AS total, MIN(p.pay_date) AS min_date
            FROM buh_payments p
            LEFT JOIN buh_contractors ct ON ct.id=p.contractor_id
            WHERE p.status IN ('draft','approve','approved')";
    if ($from !== '') { $sql .= " AND (p.pay_date IS NULL OR p.pay_date >= ?)"; $params[] = $from; }
    if ($to !== '') { $sql .= " AND (p.pay_date IS NULL OR p.pay_date <= ?)"; $params[] = $to; }
    $sql .= " GROUP BY ct.name ORDER BY total DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
      $rows[] = [(string)($r['contractor']??'—'), (string)($r['cnt']??'0'), (string)($r['total']??'0'), (string)($r['min_date']??'')];
    }
  }
} catch (Throwable $e) {
  http_response_code(500);
  echo 'Export error';
  exit;
}

$fnameMap = [
  'pay_reg' => 'payments',
  'docs_reg' => 'docs',
  'contracts_reg' => 'contracts',
  'contractors_debt' => 'to_pay_by_contractor',
];
$fname = $fnameMap[$type] ?? 'report';
$stamp = date('Y-m-d_His');

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="'.$fname.'_'.$stamp.'.csv"');

$out = fopen('php://output', 'w');
// Excel любит BOM
fwrite($out, "\xEF\xBB\xBF");

fputcsv($out, $cols, ';');
foreach ($rows as $r) {
  fputcsv($out, $r, ';');
}

fclose($out);
