<?php
$pageTitle = 'Бухгалтерия · ДДС';
$active = 'dds';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input id="ddsSearch" type="search" placeholder="Поиск по статье/комментарию" aria-label="Поиск по ДДС">
    <select id="ddsKind" data-ui="custom-select" aria-label="Раздел">
      <option value="">Все статьи</option>
      <option value="out">Расход</option>
      <option value="in">Приход</option>
    </select>
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Экспорт</a>
    <button id="btnAddDds" class="btn primary sm" type="button">+ Статья ДДС</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Статьи ДДС">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Раздел</th>
        <th>Статья</th>
        <th>Комментарий</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody id="tblDdsBody"></tbody>
  </table>
  <div id="ddsEmpty" class="buh-empty" hidden>Пока нет статей ДДС. Нажмите «+ Статья ДДС».</div>
</div>

<!-- Модалка: статья ДДС -->
<div class="modal" id="modalDds" hidden>
  <div class="glass modal-body">
    <h2 id="ddsModalTitle">Статья ДДС</h2>
    <form class="form" id="formDds" autocomplete="off">
      <input type="hidden" name="id" value="0">

      <label>Раздел
        <select name="kind" data-ui="custom-select" required>
          <option value="out">Расход</option>
          <option value="in">Приход</option>
        </select>
      </label>

      <label>Название
        <input name="name" placeholder="Например: ГСМ / Семена / Аренда" required>
      </label>

      <label>Комментарий
        <textarea name="comment" rows="3" placeholder="Опционально"></textarea>
      </label>

    </form>

    <div class="row gap modal-actions">
      <button class="btn primary" type="submit" form="formDds">Сохранить</button>
      <button class="btn" type="button" data-close>Отмена</button>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
