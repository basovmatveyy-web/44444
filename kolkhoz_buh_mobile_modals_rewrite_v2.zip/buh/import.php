<?php
$pageTitle = 'Бухгалтерия · Импорт/Экспорт';
$active = 'import';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <select data-ui="select" aria-label="Источник">
      <option value="">Выберите действие</option>
      <option value="in-payments">Импорт платежей (Excel/CSV)</option>
      <option value="in-contractors">Импорт контрагентов</option>
      <option value="out-registry">Экспорт реестра (Excel/CSV)</option>
    </select>
  </div>
  <div class="right">
    <button class="btn primary sm" type="button" disabled title="Скоро">Запустить</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Импорт и экспорт">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Действие</th>
        <th>Формат</th>
        <th>Описание</th>
        <th>Статус</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Действие">—</td>
        <td data-label="Формат">—</td>
        <td data-label="Описание">—</td>
        <td data-label="Статус"><span class="pill">Скоро</span></td>
      </tr>
    </tbody>
  </table>
  <div class="buh-empty">Здесь будет мастер импорта/экспорта: шаблоны Excel, маппинг колонок, проверка ошибок.</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
