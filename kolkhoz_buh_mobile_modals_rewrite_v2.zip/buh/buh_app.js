/* buh_app.js — логика бухгалтерского модуля (часть 2) */
(function(){
  // Полноэкранный бух‑кабинет: подстраиваем высоту под фиксированный .topbar
  function syncTopbarHeight(){
    try{
      var bar = document.querySelector('.topbar');
      if(!bar) return;
      var h = Math.ceil(bar.getBoundingClientRect().height || 0);
      if(h < 40) h = 60;
      document.documentElement.style.setProperty('--topbar-h', h + 'px');
    }catch(e){}
  }
  // сразу и при ресайзе
  syncTopbarHeight();

  // iOS/Safari: фиксируем РЕАЛЬНУЮ высоту видимой области (visualViewport) для модалок.
  // Это важно в ландшафте и при появлении/скрытии адресной строки/клавиатуры,
  // иначе кнопки внизу оказываются «под» браузерными панелями.
  function syncVh(){
    try{
      var h = 0;
      if (window.visualViewport && window.visualViewport.height){
        h = window.visualViewport.height;
        // offsets полезны при зуме/особых режимах
        document.documentElement.style.setProperty('--vv-top', (window.visualViewport.offsetTop||0) + 'px');
        document.documentElement.style.setProperty('--vv-left', (window.visualViewport.offsetLeft||0) + 'px');
      }else{
        h = (window.innerHeight || document.documentElement.clientHeight || 0);
        document.documentElement.style.setProperty('--vv-top', '0px');
        document.documentElement.style.setProperty('--vv-left', '0px');
      }
      var vh = h * 0.01;
      if(!vh || !isFinite(vh)) return;
      document.documentElement.style.setProperty('--vh', vh + 'px');
    }catch(e){}
  }

  // сразу и при ресайзе/ориентации
  syncVh();
  window.addEventListener('resize', function(){
    syncTopbarHeight();
    syncVh();
  }, {passive:true});
  window.addEventListener('orientationchange', function(){
    syncTopbarHeight();
    syncVh();
  }, {passive:true});

  // visualViewport даёт точные размеры при изменении UI Safari/клавиатуры
  try{
    if (window.visualViewport){
      window.visualViewport.addEventListener('resize', syncVh, {passive:true});
      window.visualViewport.addEventListener('scroll', syncVh, {passive:true});
    }
  }catch(e){}

  function qs(s,el){return (el||document).querySelector(s);} 
  function qsa(s,el){return Array.prototype.slice.call((el||document).querySelectorAll(s));}
  function esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);
    });
  }
  function fmtMoney(v){
    var n = Number(v||0);
    if (!isFinite(n)) n = 0;
    return n.toLocaleString('ru-RU', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₽';
  }
  function fmtDate(d){
    if(!d) return '—';
    // d может быть YYYY-MM-DD
    try{
      if(typeof d==='string' && d.length>=10){
        var parts = d.slice(0,10).split('-');
        if(parts.length===3) return parts[2]+'.'+parts[1]+'.'+parts[0];
      }
    }catch(e){}
    return String(d);
  }
  function csrf(){
    var m = qs('meta[name="csrf-token"]');
    return m ? m.content : '';
  }
  function api(url, data, method){
    method = method || (data ? 'POST' : 'GET');
    var opts = {method:method, credentials:'same-origin', headers:{'X-CSRF-Token':csrf()}};
    if(data){
      var fd = new FormData();
      Object.keys(data).forEach(function(k){ if(data[k]!==undefined) fd.append(k, data[k]); });
      opts.body = fd;
    }
    return fetch(url, opts).then(function(r){return r.json();});
  }
  function toast(msg, type){
    type = type || 'info';
    var t = document.createElement('div');
    t.className = 'toast ' + type;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.classList.add('show'); }, 10);
    setTimeout(function(){ t.classList.remove('show'); }, 2800);
    setTimeout(function(){ try{ t.remove(); }catch(e){} }, 3400);
  }
  function debounce(fn, ms){
    var to = null;
    return function(){
      var args = arguments, ctx=this;
      clearTimeout(to);
      to = setTimeout(function(){ fn.apply(ctx,args); }, ms||250);
    };
  }
  function openModal(modal){
    if(!modal) return;
    modal.hidden = false;

    // на всякий случай пересчитываем высоту видимой области прямо перед показом
    // (iOS иногда обновляет visualViewport с задержкой)
    try{ syncVh(); }catch(e){}

    // Жёстко фиксируем фон (особенно важно на iOS: просто overflow:hidden не спасает)
    try{
      if(!document.body.classList.contains('modal-open')){
        var y = window.scrollY || document.documentElement.scrollTop || 0;
        document.body.dataset.scrollY = String(y);
        document.body.style.position = 'fixed';
        document.body.style.top = (-y) + 'px';
        document.body.style.left = '0';
        document.body.style.right = '0';
        document.body.style.width = '100%';
      }
      document.body.classList.add('modal-open');
      document.documentElement.classList.add('modal-open');
    }catch(e){}

    // Прокручиваем форму в начало, чтобы заголовок/кнопки были сразу видны
    try{
      // iOS иногда применяет scrollTop до перерасчёта layout — делаем после paint
      requestAnimationFrame(function(){
        try{ syncVh(); }catch(e){}
        try{
          var f = modal.querySelector('form');
          if(f) f.scrollTop = 0;
          var mb = modal.querySelector('.modal-body');
          if(mb) mb.scrollTop = 0;
          modal.scrollTop = 0;
        }catch(e){}
      });
    }catch(e){}
  }
  function closeModal(modal){
    if(!modal) return;
    modal.hidden = true;
    // снимаем блокировку прокрутки, если других открытых модалок нет
    try{
      var anyOpen = document.querySelector('.modal:not([hidden])');
      if(!anyOpen){
        document.body.classList.remove('modal-open');
        document.documentElement.classList.remove('modal-open');
        // Возвращаем прокрутку фона
        var y = parseInt(document.body.dataset.scrollY || '0', 10) || 0;
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.left = '';
        document.body.style.right = '';
        document.body.style.width = '';
        try{ delete document.body.dataset.scrollY; }catch(e){}
        window.scrollTo(0, y);
      }
    }catch(e){}
  }
  function bindModal(modal){
    if(!modal) return;
    modal.addEventListener('click', function(e){
      if(e.target === modal) closeModal(modal);
    });
    qsa('[data-close]', modal).forEach(function(b){
      b.addEventListener('click', function(){ closeModal(modal); });
    });
    document.addEventListener('keydown', function(e){
      if(e.key==='Escape' && !modal.hidden) closeModal(modal);
    });

    // На мобиле убираем горизонтальную «размазню» при диагональных свайпах
    // (разрешаем только вертикальный скролл внутри формы)
    try{
      var scroller = modal.querySelector('form') || modal.querySelector('.modal-body');
      if(scroller){
        var sx=0, sy=0;
        scroller.addEventListener('touchstart', function(ev){
          if(!ev.touches || !ev.touches[0]) return;
          sx = ev.touches[0].clientX;
          sy = ev.touches[0].clientY;
        }, {passive:true});
        scroller.addEventListener('touchmove', function(ev){
          if(!ev.touches || !ev.touches[0]) return;
          var dx = ev.touches[0].clientX - sx;
          var dy = ev.touches[0].clientY - sy;
          // если движение больше по X — гасим, чтобы окно не «елозило»
          if(Math.abs(dx) > Math.abs(dy) + 6){
            ev.preventDefault();
          }
        }, {passive:false});
      }
    }catch(e){}
  }
  function formToObj(form){
    var o = {};
    new FormData(form).forEach(function(v,k){ o[k]=v; });
    return o;
  }
  var ROLE = (document.body && document.body.dataset) ? (document.body.dataset.role || "") : "";

  function setForm(form, data){
    Object.keys(data||{}).forEach(function(k){
      var el = qs('[name="'+k+'"]', form);
      if(!el) return;
      el.value = data[k] == null ? '' : data[k];
      try{ el.dispatchEvent(new Event('change', {bubbles:true})); }catch(e){}
    });
  }

  // Справочники
  var ContractorTypeLabel = {
    supplier:'Поставщик',
    buyer:'Покупатель',
    landlord:'Пайщик/арендодатель',
    employee:'Сотрудник',
    other:'Прочее'
  };
  function typePill(type){
    var t = ContractorTypeLabel[type] || type || '—';
    return '<span class="pill">'+esc(t)+'</span>';
  }
  var PayStatusLabel = {
    draft:'Черновик',
    approve:'На согласовании',
    approved:'Согласовано',
    paid:'Оплачено',
    rejected:'Отклонено'
  };
  var DocStatusLabel = {
    draft:'Черновик',
    received:'Получено',
    approved:'Согласовано',
    paid:'Оплачено',
    closed:'Закрыто',
    rejected:'Отклонено'
  };
  var DocTypeLabel = {invoice:'Счёт', act:'Акт', waybill:'Накладная', upd:'УПД', other:'Другое'};

  function statusPill(label){
    return '<span class="pill">'+esc(label||'—')+'</span>';
  }

  // Загружаем список контрагентов для селектов
  var contractorsCache = null;
  function loadContractorsMini(){
    if(contractorsCache) return Promise.resolve(contractorsCache);
    return api('api/contractors.php?action=list', null, 'GET').then(function(r){
      if(!r.ok) throw new Error(r.error||'Ошибка');
      contractorsCache = r.items || [];
      return contractorsCache;
    });
  }
  function fillContractorSelect(sel, items, keepValue){
    if(!sel) return;
    var cur = keepValue ? sel.value : '';
    // очищаем, оставляя первый option если он пустой
    var first = sel.options[0] && sel.options[0].value==='' ? sel.options[0].text : null;
    sel.innerHTML = '';
    if(first!==null){
      var o0 = document.createElement('option');
      o0.value=''; o0.text = first;
      sel.appendChild(o0);
    }
    items.forEach(function(it){
      var o = document.createElement('option');
      o.value = it.id;
      o.text = it.name;
      sel.appendChild(o);
    });
    if(keepValue) sel.value = cur;
    try{ sel.dispatchEvent(new Event('change', {bubbles:true})); }catch(e){}
  }



  // Загружаем список статей ДДС для селектов
  var ddsCache = null;
  function loadDdsMini(){
    if(ddsCache) return Promise.resolve(ddsCache);
    return api('api/dds.php?action=list', null, 'GET').then(function(r){
      if(!r.ok) throw new Error(r.error||'Ошибка');
      ddsCache = r.items || [];
      return ddsCache;
    });
  }
  function invalidateDdsCache(){ ddsCache = null; }
  function fillDdsSelect(sel, items, keepValue){
    if(!sel) return;
    var cur = keepValue ? sel.value : '';
    var first = sel.options[0] && sel.options[0].value==='' ? sel.options[0].text : null;
    sel.innerHTML='';
    if(first!==null){ var o0=document.createElement('option'); o0.value=''; o0.text=first; sel.appendChild(o0); }
    items.forEach(function(it){
      var o=document.createElement('option');
      o.value=it.id;
      o.text=(it.kind==='in' ? 'Приход: ' : 'Расход: ') + it.name;
      sel.appendChild(o);
    });
    if(keepValue) sel.value=cur;
    try{ sel.dispatchEvent(new Event('change', {bubbles:true})); }catch(e){}
  }

  // ---------------- Dashboard ----------------
  function initDashboard(){
    api('api/kpi.php?action=dashboard', null, 'GET').then(function(r){
      if(!r.ok) return;
      var k = r.kpi || {};
      var el;
      el = qs('#kpiApprove'); if(el) el.textContent = String(k.payments_approve ?? '0');
      el = qs('#kpiOverdue'); if(el) el.textContent = String(k.payments_overdue ?? '0');
      el = qs('#kpi7d'); if(el) el.textContent = fmtMoney(k.pay_7d_sum ?? 0);
      el = qs('#kpiDocs'); if(el) el.textContent = String(k.new_docs ?? '0');
    }).catch(function(){});

    api('api/kpi.php?action=feed', null, 'GET').then(function(r){
      if(!r.ok) return;
      var body = qs('#tblFeedBody');
      var empty = qs('#emptyOps');
      if(!body) return;
      body.innerHTML = '';
      (r.items||[]).forEach(function(it){
        var who = (it.surname||it.name) ? ((it.surname||'')+' '+(it.name||'')).trim() : (it.username||'—');
        var type = it.entity === 'payment' ? 'Платёж' : (it.entity==='doc' ? 'Документ' : (it.entity==='contract' ? 'Договор' : 'Контрагент'));
        var tr = document.createElement('tr');
        tr.innerHTML =
          '<td data-label="Дата">'+esc(String(it.created_at||'').replace('T',' ').slice(0,16))+'</td>'+
          '<td data-label="Тип">'+esc(type)+'</td>'+
          '<td data-label="Описание">'+esc(it.title||'')+'</td>'+
          '<td data-label="Статус">'+statusPill(it.status||'')+'</td>'+
          '<td data-label="Кто">'+esc(who||'—')+'</td>';
        body.appendChild(tr);
      });
      if(empty) empty.hidden = (r.items||[]).length>0;
    }).catch(function(){});
  }

  // ---------------- Contractors ----------------
  function initContractors(){
    var inp = qs('#ctrSearch');
    var selType = qs('#ctrType');
    var body = qs('#tblContractorsBody');
    var empty = qs('#ctrEmpty');
    var btnAdd = qs('#btnAddContractor');
    var modal = qs('#modalContractor');
    var form = qs('#formContractor');
    var title = qs('#ctrModalTitle');

    bindModal(modal);

    function render(items){
      body.innerHTML = '';
      if(!items || items.length===0){
        if(empty) empty.hidden = false;
        return;
      }
      if(empty) empty.hidden = true;
      items.forEach(function(it){
        var bank = (it.bank_name||'') + (it.bik?(' · БИК '+it.bik):'') + (it.account?(' · '+it.account):'');
        var tr = document.createElement('tr');
        tr.innerHTML =
          '<td data-label="Название / ФИО"><strong>'+esc(it.name||'')+'</strong></td>'+
          '<td data-label="ИНН">'+esc(it.inn||'—')+'</td>'+
          '<td data-label="Тип">'+typePill(it.type)+'</td>'+
          '<td data-label="Телефон">'+esc(it.phone||'—')+'</td>'+
          '<td data-label="Банк/реквизиты">'+esc(bank || '—')+'</td>'+
          '<td data-label="Действия">'+
            '<button class="btn sm" type="button" data-act="edit" data-id="'+esc(it.id)+'">Изменить</button> '+
            '<button class="btn sm" type="button" data-act="del" data-id="'+esc(it.id)+'">Удалить</button>'+
          '</td>';
        body.appendChild(tr);
      });
    }

    function load(){
      var q = inp ? inp.value.trim() : '';
      var t = selType ? selType.value : '';
      var url = 'api/contractors.php?action=list&q='+encodeURIComponent(q)+'&type='+encodeURIComponent(t);
      api(url, null, 'GET').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        contractorsCache = null; // чтобы селекты обновлялись
        render(r.items||[]);
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    }

    var loadDeb = debounce(load, 250);
    if(inp) inp.addEventListener('input', loadDeb);
    if(selType) selType.addEventListener('change', load);

    function resetForm(){
      form.reset();
      qs('[name="id"]', form).value = '0';
      try{ form.querySelector('[name="type"]').dispatchEvent(new Event('change', {bubbles:true})); }catch(e){}
    }

    if(btnAdd) btnAdd.addEventListener('click', function(){
      resetForm();
      if(title) title.textContent = 'Новый контрагент';
      openModal(modal);
    });

    body.addEventListener('click', function(e){
      var b = e.target.closest('button[data-act]');
      if(!b) return;
      var act = b.dataset.act;
      var id = b.dataset.id;
      if(act==='edit'){
        api('api/contractors.php?action=get&id='+encodeURIComponent(id), null, 'GET').then(function(r){
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          resetForm();
          setForm(form, r.item||{});
          if(title) title.textContent = 'Контрагент: ' + (r.item.name||'');
          openModal(modal);
        });
      }
      if(act==='del'){
        if(!confirm('Удалить контрагента?')) return;
        api('api/contractors.php?action=delete', {id:id}, 'POST').then(function(r){
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          toast('Удалено', 'ok');
          load();
        });
      }
    });

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var data = formToObj(form);
      api('api/contractors.php?action=save', data, 'POST').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        toast('Сохранено', 'ok');
        closeModal(modal);
        load();
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    });

    load();
  }

  // ---------------- Contracts ----------------
  function initContracts(){
    var inp = qs('#conSearch');
    var selStatus = qs('#conStatus');
    var body = qs('#tblContractsBody');
    var empty = qs('#conEmpty');
    var btnAdd = qs('#btnAddContract');
    var modal = qs('#modalContract');
    var form = qs('#formContract');
    var title = qs('#conModalTitle');
    var selCtr = qs('#conContractor');

    bindModal(modal);

    function loadContractors(){
      return loadContractorsMini().then(function(items){
        fillContractorSelect(selCtr, items, true);
      }).catch(function(){});
    }

    function render(items){
      body.innerHTML = '';
      if(!items || items.length===0){
        if(empty) empty.hidden = false;
        return;
      }
      if(empty) empty.hidden = true;
      items.forEach(function(it){
        var tr = document.createElement('tr');
        tr.innerHTML =
          '<td data-label="Номер"><strong>'+esc(it.number||'')+'</strong></td>'+
          '<td data-label="Дата">'+esc(fmtDate(it.doc_date))+'</td>'+
          '<td data-label="Контрагент">'+esc(it.contractor_name||'—')+'</td>'+
          '<td data-label="Предмет">'+esc(it.subject||'—')+'</td>'+
          '<td data-label="Сумма">'+esc(it.amount ? fmtMoney(it.amount) : '—')+'</td>'+
          '<td data-label="Статус">'+statusPill({active:'Активен',closed:'Закрыт',archive:'Архив'}[it.status] || it.status)+'</td>'+
          '<td data-label="Действия">'+
            '<button class="btn sm" type="button" data-act="edit" data-id="'+esc(it.id)+'">Изменить</button> '+
            '<button class="btn sm" type="button" data-act="del" data-id="'+esc(it.id)+'">Удалить</button>'+
          '</td>';
        body.appendChild(tr);
      });
    }

    function load(){
      var q = inp ? inp.value.trim() : '';
      var st = selStatus ? selStatus.value : '';
      var url = 'api/contracts.php?action=list&q='+encodeURIComponent(q)+'&status='+encodeURIComponent(st);
      api(url, null, 'GET').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        render(r.items||[]);
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    }

    var loadDeb = debounce(load, 250);
    if(inp) inp.addEventListener('input', loadDeb);
    if(selStatus) selStatus.addEventListener('change', load);

    function reset(){
      form.reset();
      qs('[name="id"]', form).value = '0';
      loadContractors();
    }

    if(btnAdd) btnAdd.addEventListener('click', function(){
      reset();
      if(title) title.textContent = 'Новый договор';
      openModal(modal);
    });

    body.addEventListener('click', function(e){
      var b = e.target.closest('button[data-act]');
      if(!b) return;
      var act = b.dataset.act;
      var id = b.dataset.id;
      if(act==='edit'){
        Promise.all([
          api('api/contracts.php?action=get&id='+encodeURIComponent(id), null, 'GET'),
          loadContractors()
        ]).then(function(res){
          var r = res[0];
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          reset();
          setForm(form, r.item||{});
          if(title) title.textContent = 'Договор: ' + (r.item.number||'');
          openModal(modal);
        });
      }
      if(act==='del'){
        if(!confirm('Удалить договор?')) return;
        api('api/contracts.php?action=delete', {id:id}, 'POST').then(function(r){
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          toast('Удалено', 'ok');
          load();
        });
      }
    });

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var data = formToObj(form);
      api('api/contracts.php?action=save', data, 'POST').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        toast('Сохранено', 'ok');
        closeModal(modal);
        load();
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    });

    loadContractors().then(load);
  }

  // ---------------- Payments ----------------

  // ---------------- Payments ----------------
  function initPayments(){
    var inp = qs('#paySearch');
    var selStatus = qs('#payStatus');
    var selMethod = qs('#payMethod');
    var from = qs('#payFrom');
    var to = qs('#payTo');
    var btnAdd = qs('#btnAddPayment');
    var body = qs('#tblPaymentsBody');
    var empty = qs('#payEmpty');

    var modal = qs('#modalPayment');
    var form = qs('#formPayment');
    var title = qs('#payModalTitle');
    var selCtr = qs('#payContractor');
    var selContract = qs('#payContract');
    var selDoc = qs('#payDoc');
    var selDds = qs('#payDds');

    bindModal(modal);

    var pendingContractId = '';
    var pendingDocId = '';

    function setReadOnly(ro){
      qsa('input,select,textarea', form).forEach(function(el){ el.disabled = !!ro; });
      var btnSave = qs('button[type="submit"]', form);
      if(btnSave) btnSave.hidden = !!ro;
    }

    function reset(){
      form.reset();
      setForm(form, {id:0, status:'draft', method:'bank'});
      pendingContractId = '';
      pendingDocId = '';
      if(selContract){ selContract.innerHTML = '<option value="">— не выбран —</option>'; }
      if(selDoc){ selDoc.innerHTML = '<option value="">— не выбран —</option>'; }
      setReadOnly(false);
    }

    function loadContractors(){
      return loadContractorsMini().then(function(items){
        fillContractorSelect(selCtr, items, true);
      }).catch(function(){});
    }

    function loadDds(){
      return loadDdsMini().then(function(items){
        fillDdsSelect(selDds, items, true);
      }).catch(function(){});
    }

    function fillSimpleSelect(sel, items, labelFn, keepValue){
      if(!sel) return;
      var cur = keepValue ? sel.value : '';
      var first = sel.options[0] && sel.options[0].value==='' ? sel.options[0].text : '— не выбран —';
      sel.innerHTML = '';
      var o0 = document.createElement('option');
      o0.value = '';
      o0.text = first;
      sel.appendChild(o0);
      (items||[]).forEach(function(it){
        var o = document.createElement('option');
        o.value = it.id;
        o.text = labelFn(it);
        sel.appendChild(o);
      });
      if(keepValue) sel.value = cur;
      try{ sel.dispatchEvent(new Event('change', {bubbles:true})); }catch(e){}
    }

    function loadContractsForContractor(contractorId){
      if(!selContract) return;
      if(!contractorId){
        selContract.innerHTML = '<option value="">— не выбран —</option>';
        return;
      }
      var url = 'api/contracts.php?action=list&contractor_id='+encodeURIComponent(contractorId);
      api(url, null, 'GET').then(function(r){
        if(!r.ok) return;
        fillSimpleSelect(selContract, r.items||[], function(it){
          var num = it.number ? ('№'+it.number) : 'Без номера';
          var dt = it.doc_date ? (' от '+fmtDate(it.doc_date)) : '';
          return num+dt;
        }, false);
        if(pendingContractId){ selContract.value = pendingContractId; pendingContractId=''; }
      }).catch(function(){});
    }

    function loadDocsForContractor(contractorId){
      if(!selDoc) return;
      if(!contractorId){
        selDoc.innerHTML = '<option value="">— не выбран —</option>';
        return;
      }
      var url = 'api/docs.php?action=list&contractor_id='+encodeURIComponent(contractorId);
      api(url, null, 'GET').then(function(r){
        if(!r.ok) return;
        fillSimpleSelect(selDoc, r.items||[], function(it){
          var n = it.number ? ('№'+it.number) : ('#'+it.id);
          var dt = it.doc_date ? (' '+fmtDate(it.doc_date)) : '';
          return n + dt;
        }, false);
        if(pendingDocId){ selDoc.value = pendingDocId; pendingDocId=''; }
      }).catch(function(){});
    }

    if(selCtr){
      selCtr.addEventListener('change', function(){
        var cid = selCtr.value || '';
        loadContractsForContractor(cid);
        loadDocsForContractor(cid);
      });
    }

    function actionButtons(it){
      var s = it.status;
      var id = it.id;
      var btns = [];

      if(ROLE === 'admin') {
        btns.push('<button class="btn sm" type="button" data-act="edit" data-id="'+esc(id)+'">Изменить</button>');
        btns.push('<button class="btn sm" type="button" data-act="del" data-id="'+esc(id)+'">Удалить</button>');
        if(s==='draft') btns.push('<button class="btn sm" type="button" data-act="to_approve" data-id="'+esc(id)+'">На согласование</button>');
        if(s==='approve') {
          btns.push('<button class="btn sm" type="button" data-act="approve" data-id="'+esc(id)+'">Согласовать</button>');
          btns.push('<button class="btn sm" type="button" data-act="reject" data-id="'+esc(id)+'">Отклонить</button>');
        }
        if(s==='approved') btns.push('<button class="btn sm" type="button" data-act="paid" data-id="'+esc(id)+'">Оплачено</button>');
        if(s==='rejected') btns.push('<button class="btn sm" type="button" data-act="to_draft" data-id="'+esc(id)+'">В черновик</button>');
      } else {
        // buh
        if(s==='draft') {
          btns.push('<button class="btn sm" type="button" data-act="edit" data-id="'+esc(id)+'">Изменить</button>');
          btns.push('<button class="btn sm" type="button" data-act="to_approve" data-id="'+esc(id)+'">На согласование</button>');
          btns.push('<button class="btn sm" type="button" data-act="del" data-id="'+esc(id)+'">Удалить</button>');
        } else {
          btns.push('<button class="btn sm" type="button" data-act="view" data-id="'+esc(id)+'">Открыть</button>');
          if(s==='approve') btns.push('<button class="btn sm" type="button" data-act="to_draft" data-id="'+esc(id)+'">Отозвать</button>');
          if(s==='rejected') btns.push('<button class="btn sm" type="button" data-act="to_draft" data-id="'+esc(id)+'">В черновик</button>');
        }
      }

      return btns.join(' ');
    }

    function render(items){
      body.innerHTML = '';
      if(!items || items.length===0){
        if(empty) empty.hidden = false;
        return;
      }
      if(empty) empty.hidden = true;
      items.forEach(function(it){
        var tr = document.createElement('tr');
        tr.innerHTML =
          '<td data-label="Дата">'+esc(fmtDate(it.pay_date))+'</td>'+
          '<td data-label="Контрагент">'+esc(it.contractor_name||'—')+'</td>'+
          '<td data-label="Статья">'+esc(it.dds_name||'—')+'</td>'+
          '<td data-label="Назначение">'+esc(it.purpose||'—')+'</td>'+
          '<td data-label="Сумма"><strong>'+esc(fmtMoney(it.amount))+'</strong></td>'+
          '<td data-label="Статус">'+statusPill(PayStatusLabel[it.status] || it.status)+'</td>'+
          '<td data-label="Действия">'+actionButtons(it)+'</td>';
        body.appendChild(tr);
      });
    }

    function load(){
      var q = inp ? inp.value.trim() : '';
      var st = selStatus ? selStatus.value : '';
      var m = selMethod ? selMethod.value : '';
      var f = from ? from.value : '';
      var t = to ? to.value : '';
      var url = 'api/payments.php?action=list&q='+encodeURIComponent(q)+'&status='+encodeURIComponent(st)+'&method='+encodeURIComponent(m)+'&from='+encodeURIComponent(f)+'&to='+encodeURIComponent(t);
      api(url, null, 'GET').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        render(r.items||[]);
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    }

    function openPayment(id, ro){
      api('api/payments.php?action=get&id='+encodeURIComponent(id), null, 'GET').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        reset();
        var it = r.item||{};
        pendingContractId = it.contract_id || '';
        pendingDocId = it.doc_id || '';
        setForm(form, it);
        if(title) title.textContent = 'Платёж #'+id;
        // блокируем статус для бухгалтера
        if(ROLE === 'buh'){
          var stEl = qs('[name="status"]', form);
          if(stEl) stEl.disabled = true;
        }
        if(ro) setReadOnly(true);
        openModal(modal);
      });
    }

    function transition(id, toStatus, confirmText){
      if(confirmText && !confirm(confirmText)) return;
      api('api/payments.php?action=transition', {id:id, to:toStatus}, 'POST').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        toast('Статус обновлён', 'ok');
        load();
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    }

    if(inp) inp.addEventListener('input', debounce(load, 250));
    if(selStatus) selStatus.addEventListener('change', load);
    if(selMethod) selMethod.addEventListener('change', load);
    if(from) from.addEventListener('change', load);
    if(to) to.addEventListener('change', load);

    if(btnAdd){
      btnAdd.addEventListener('click', function(){
        reset();
        if(title) title.textContent = 'Новый платёж';
        // статус скрыт для бухгалтера
        if(ROLE === 'buh'){
          var stEl = qs('[name="status"]', form);
          if(stEl) stEl.disabled = true;
        }
        openModal(modal);
      });
    }

    body.addEventListener('click', function(e){
      var b = e.target.closest('button[data-act]');
      if(!b) return;
      var act = b.getAttribute('data-act');
      var id = b.getAttribute('data-id');
      if(!id) return;

      if(act==='edit') return openPayment(id, false);
      if(act==='view') return openPayment(id, true);
      if(act==='to_approve') return transition(id, 'approve');
      if(act==='approve') return transition(id, 'approved');
      if(act==='reject') return transition(id, 'rejected', 'Отклонить платёж?');
      if(act==='to_draft') return transition(id, 'draft');
      if(act==='paid') return transition(id, 'paid', 'Отметить как оплаченный?');

      if(act==='del'){
        if(!confirm('Удалить платёж?')) return;
        api('api/payments.php?action=delete', {id:id}, 'POST').then(function(r){
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          toast('Удалено', 'ok');
          load();
        });
      }
    });

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var data = formToObj(form);
      api('api/payments.php?action=save', data, 'POST').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        toast('Сохранено', 'ok');
        closeModal(modal);
        load();
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    });

    Promise.all([loadContractors(), loadDds()]).then(function(){
      load();
      // авто-открытие по ссылке ?open=ID
      try{
        var usp = new URLSearchParams(location.search);
        var openId = usp.get('open');
        if(openId){
          openPayment(openId, ROLE==='buh');
        }
      }catch(e){}
    });
  }

  // ---------------- Docs ----------------
  function initDocs(){
    var inp = qs('#docSearch');
    var selDir = qs('#docDirection');
    var selType = qs('#docType');
    var selStatus = qs('#docStatus');
    var body = qs('#tblDocsBody');
    var empty = qs('#docEmpty');
    var btnAdd = qs('#btnAddDoc');
    var modal = qs('#modalDoc');
    var form = qs('#formDoc');
    var title = qs('#docModalTitle');
    var selCtr = qs('#docContractor');

    bindModal(modal);

    function loadContractors(){
      return loadContractorsMini().then(function(items){
        fillContractorSelect(selCtr, items, true);
      }).catch(function(){});
    }

    function render(items){
      body.innerHTML = '';
      if(!items || items.length===0){
        if(empty) empty.hidden = false;
        return;
      }
      if(empty) empty.hidden = true;
      items.forEach(function(it){
        var type = (it.direction==='out' ? 'Исх. ' : 'Вх. ') + (DocTypeLabel[it.doc_type] || it.doc_type || '');
        var tr = document.createElement('tr');
        tr.innerHTML =
          '<td data-label="Дата">'+esc(fmtDate(it.doc_date))+'</td>'+
          '<td data-label="Тип">'+esc(type)+'</td>'+
          '<td data-label="Контрагент">'+esc(it.contractor_name||'—')+'</td>'+
          '<td data-label="Номер">'+esc(it.number||'—')+'</td>'+
          '<td data-label="Сумма">'+esc(it.amount ? fmtMoney(it.amount) : '—')+'</td>'+
          '<td data-label="Статус">'+statusPill(DocStatusLabel[it.status] || it.status)+'</td>'+
          '<td data-label="Действия">'+
            '<button class="btn sm" type="button" data-act="edit" data-id="'+esc(it.id)+'">Изменить</button> '+
            '<button class="btn sm" type="button" data-act="del" data-id="'+esc(it.id)+'">Удалить</button>'+
          '</td>';
        body.appendChild(tr);
      });
    }

    function load(){
      var q = inp ? inp.value.trim() : '';
      var dir = selDir ? selDir.value : '';
      var tp = selType ? selType.value : '';
      var st = selStatus ? selStatus.value : '';
      var url = 'api/docs.php?action=list&q='+encodeURIComponent(q)+'&direction='+encodeURIComponent(dir)+'&status='+encodeURIComponent(st);
      // тип фильтруем через q параметр (простая реализация):
      if(tp) url += '&q='+encodeURIComponent(q ? (q+' '+tp) : tp);
      api(url, null, 'GET').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        render(r.items||[]);
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    }

    var loadDeb = debounce(load, 250);
    if(inp) inp.addEventListener('input', loadDeb);
    [selDir, selType, selStatus].forEach(function(el){ if(el) el.addEventListener('change', load); });

    function reset(){
      form.reset();
      qs('[name="id"]', form).value = '0';
      loadContractors();
    }

    if(btnAdd) btnAdd.addEventListener('click', function(){
      reset();
      if(title) title.textContent = 'Новый документ';
      openModal(modal);
    });

    body.addEventListener('click', function(e){
      var b = e.target.closest('button[data-act]');
      if(!b) return;
      var act = b.dataset.act;
      var id = b.dataset.id;
      if(act==='edit'){
        Promise.all([
          api('api/docs.php?action=get&id='+encodeURIComponent(id), null, 'GET'),
          loadContractors()
        ]).then(function(res){
          var r = res[0];
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          reset();
          setForm(form, r.item||{});
          if(title) title.textContent = 'Документ #'+id;
          openModal(modal);
        });
      }
      if(act==='del'){
        if(!confirm('Удалить документ?')) return;
        api('api/docs.php?action=delete', {id:id}, 'POST').then(function(r){
          if(!r.ok) return toast(r.error||'Ошибка', 'err');
          toast('Удалено', 'ok');
          load();
        });
      }
    });

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var data = formToObj(form);
      api('api/docs.php?action=save', data, 'POST').then(function(r){
        if(!r.ok) return toast(r.error||'Ошибка', 'err');
        toast('Сохранено', 'ok');
        closeModal(modal);
        load();
      }).catch(function(){ toast('Ошибка сети', 'err'); });
    });

    loadContractors().then(load);
  }

  // ---------------- Boot ----------------
  var page = (document.body && document.body.dataset) ? document.body.dataset.buhPage : '';
  if(page==='dashboard') initDashboard();
  if(page==='contractors') initContractors();
  if(page==='contracts') initContracts();
  if(page==='payments') initPayments();
  if(page==='docs') initDocs();
})();
