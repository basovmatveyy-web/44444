<?php
$pageTitle = 'Бухгалтерия · Договоры';
$active = 'contracts';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input id="conSearch" type="search" placeholder="Поиск (номер, контрагент, предмет)" aria-label="Поиск договоров">
    <select id="conStatus" data-ui="custom-select" aria-label="Статус">
      <option value="">Все статусы</option>
      <option value="active">Активен</option>
      <option value="closed">Закрыт</option>
      <option value="archive">Архив</option>
    </select>
  </div>
  <div class="right">
    <button id="btnAddContract" class="btn primary sm" type="button">+ Договор</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Реестр договоров">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Номер</th>
        <th>Дата</th>
        <th>Контрагент</th>
        <th>Предмет</th>
        <th>Сумма</th>
        <th>Статус</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody id="tblContractsBody"></tbody>
  </table>
  <div id="conEmpty" class="buh-empty" hidden>Пока нет договоров. Нажмите «+ Договор».</div>
</div>

<!-- Модалка: договор -->
<div class="modal" id="modalContract" hidden>
  <div class="glass modal-body">
    <h2 id="conModalTitle">Договор</h2>
    <form class="form" id="formContract" autocomplete="off">
      <input type="hidden" name="id" value="0">

      <label>Контрагент
        <select name="contractor_id" id="conContractor" data-ui="custom-select" required>
          <option value="">— выберите —</option>
        </select>
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Номер
          <input name="number" placeholder="№" required>
        </label>
        <label style="flex:1">Дата
          <input type="date" name="doc_date">
        </label>
      </div>

      <label>Предмет
        <input name="subject" placeholder="Аренда, поставка, услуги...">
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Сумма (если есть)
          <input name="amount" inputmode="decimal" placeholder="0.00">
        </label>
        <label style="flex:1">Статус
          <select name="status" data-ui="custom-select">
            <option value="active">Активен</option>
            <option value="closed">Закрыт</option>
            <option value="archive">Архив</option>
          </select>
        </label>
      </div>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Начало
          <input type="date" name="start_date">
        </label>
        <label style="flex:1">Окончание
          <input type="date" name="end_date">
        </label>
      </div>

      <label>Комментарий
        <textarea name="comment" rows="3" placeholder="Примечание"></textarea>
      </label>

    </form>

    <div class="row gap modal-actions">
      <button class="btn primary" type="submit" form="formContract">Сохранить</button>
      <button class="btn" type="button" data-close>Отмена</button>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
