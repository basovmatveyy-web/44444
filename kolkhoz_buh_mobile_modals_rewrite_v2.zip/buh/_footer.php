    </div><!-- /.buh-page -->
  </section>
</main>

<footer class="foot muted sm">© <?=date('Y')?> СХПК «Береговой»</footer>
<script src="../custom_select.js"></script>
<script src="buh_app.js"></script>
</body>
</html>
