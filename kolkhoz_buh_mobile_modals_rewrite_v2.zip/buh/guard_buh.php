<?php
require_once __DIR__ . '/../config.php';

if (empty($_SESSION['user'])) {
  header('Location: ../index.php');
  exit;
}

$role = (string)($_SESSION['user']['role'] ?? 'user');
if (!in_array($role, ['admin','buh'], true)) {
  http_response_code(403);
  $u = $_SESSION['user'];
  $name = trim((string)($u['surname'] ?? '') . ' ' . (string)($u['name'] ?? ''));
  $name = $name !== '' ? $name : (string)($u['username'] ?? '');
  ?><!doctype html>
  <html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Доступ запрещён</title>
    <link rel="icon" href="../logo.png">
    <link rel="stylesheet" href="../styles.css">
  </head>
  <body class="bg">
  <div id="bg-layer"></div><div id="bg-overlay"></div><div class="overlay"></div>
  <header class="topbar">
    <div class="brand"><img src="../logo.png" class="logo" alt=""><span>СХПК «Береговой»</span></div>
    <nav class="topnav">
      <a class="link" href="../modules.php">Разделы</a>
      <a class="link" href="../logout.php">Выход</a>
    </nav>
  </header>
  <main class="center-wrap">
    <section class="glass card-xl">
      <h1>Нет доступа</h1>
      <p class="muted">Раздел «Бухгалтерия» доступен только ролям <b>Админ</b> и <b>Бухгалтер</b>.</p>
      <div class="row gap">
        <a class="btn primary" href="../modules.php">К разделам</a>
        <a class="btn" href="../dashboard.php">Растениеводство</a>
      </div>
      <div class="muted sm" style="margin-top:12px">Вы вошли как: <b><?=safe($name)?></b></div>
    </section>
  </main>
  <footer class="foot muted sm">© <?=date('Y')?> СХПК «Береговой»</footer>
  </body>
  </html>
  <?php
  exit;
}
