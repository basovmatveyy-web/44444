<?php
$pageTitle = 'Бухгалтерия · Контрагенты';
$active = 'contractors';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input id="ctrSearch" type="search" placeholder="Поиск (название, ИНН, телефон)" aria-label="Поиск контрагентов">
    <select id="ctrType" data-ui="custom-select" aria-label="Тип контрагента">
      <option value="">Все типы</option>
      <option value="supplier">Поставщик</option>
      <option value="buyer">Покупатель</option>
      <option value="landlord">Пайщик/арендодатель</option>
      <option value="employee">Сотрудник</option>
      <option value="other">Прочее</option>
    </select>
  </div>
  <div class="right">
    <button id="btnAddContractor" class="btn primary sm" type="button">+ Контрагент</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Реестр контрагентов">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Название / ФИО</th>
        <th>ИНН</th>
        <th>Тип</th>
        <th>Телефон</th>
        <th>Банк/реквизиты</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody id="tblContractorsBody"></tbody>
  </table>
  <div id="ctrEmpty" class="buh-empty" hidden>Пока нет контрагентов. Нажмите «+ Контрагент».</div>
</div>

<!-- Модалка: контрагент -->
<div class="modal" id="modalContractor" hidden>
  <div class="glass modal-body">
    <h2 id="ctrModalTitle">Контрагент</h2>
    <form class="form" id="formContractor" autocomplete="off">
      <input type="hidden" name="id" value="0">

      <label>Тип
        <select name="type" data-ui="custom-select" required>
          <option value="supplier">Поставщик</option>
          <option value="buyer">Покупатель</option>
          <option value="landlord">Пайщик/арендодатель</option>
          <option value="employee">Сотрудник</option>
          <option value="other">Прочее</option>
        </select>
      </label>

      <label>Название / ФИО
        <input name="name" placeholder="Например: ООО «Ромашка»" required>
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">ИНН
          <input name="inn" inputmode="numeric" placeholder="ИНН">
        </label>
        <label style="flex:1">КПП
          <input name="kpp" inputmode="numeric" placeholder="КПП">
        </label>
      </div>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Телефон
          <input name="phone" inputmode="tel" placeholder="+7...">
        </label>
        <label style="flex:1">Email
          <input name="email" inputmode="email" placeholder="mail@...">
        </label>
      </div>

      <label>Банк
        <input name="bank_name" placeholder="Название банка">
      </label>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">БИК
          <input name="bik" inputmode="numeric" placeholder="БИК">
        </label>
        <label style="flex:1">Р/с
          <input name="account" inputmode="numeric" placeholder="Расчётный счёт">
        </label>
      </div>

      <label>Адрес
        <input name="address" placeholder="Адрес">
      </label>

      <label>Комментарий
        <textarea name="comment" rows="3" placeholder="Примечание"></textarea>
      </label>

    </form>

    <div class="row gap modal-actions">
      <button class="btn primary" type="submit" form="formContractor">Сохранить</button>
      <button class="btn" type="button" data-close>Отмена</button>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
