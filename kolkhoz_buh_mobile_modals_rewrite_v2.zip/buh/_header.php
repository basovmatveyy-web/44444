<?php
require_once __DIR__ . '/guard_buh.php';

$user = $_SESSION['user'];
$role = (string)($user['role'] ?? 'user');
$fullName = trim((string)($user['surname'] ?? '') . ' ' . (string)($user['name'] ?? ''));
$fullName = $fullName !== '' ? $fullName : (string)($user['username'] ?? '');

$roleLabel = 'Пользователь';
if ($role === 'admin') $roleLabel = 'Админ';
if ($role === 'buh') $roleLabel = 'Бухгалтер';

$pageTitle = $pageTitle ?? 'Бухгалтерия';
$active = $active ?? 'dashboard';

$nav = [
  'dashboard'   => ['label' => 'Панель',        'href' => 'index.php'],
  'payments'    => ['label' => 'Платежи',       'href' => 'payments.php'],
  'docs'        => ['label' => 'Документы',     'href' => 'docs.php'],
  'cash'        => ['label' => 'Касса',         'href' => 'cash.php'],
  'contractors' => ['label' => 'Контрагенты',   'href' => 'contractors.php'],
  'contracts'   => ['label' => 'Договоры',      'href' => 'contracts.php'],
  'salary'      => ['label' => 'Зарплата',      'href' => 'salary.php'],
  'inventory'   => ['label' => 'Склад/МТР',     'href' => 'inventory.php'],
  'dds'         => ['label' => 'ДДС',           'href' => 'dds.php'],
  'approvals'   => ['label' => 'Согласования',  'href' => 'approvals.php'],
  'import'      => ['label' => 'Импорт/Экспорт','href' => 'import.php'],
  'reports'     => ['label' => 'Отчёты',        'href' => 'reports.php'],
  'dicts'       => ['label' => 'Справочники',   'href' => 'dicts.php'],
];
if ($role === 'admin') {
  $nav['settings'] = ['label' => 'Настройки', 'href' => 'settings.php'];
}
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="<?=safe($_SESSION['csrf'] ?? '')?>">
  <title>СХПК «Береговой» — <?=safe($pageTitle)?></title>
  <link rel="icon" href="../logo.png">
  <link rel="stylesheet" href="../styles.css">
  <link rel="stylesheet" href="../select_patch.css">
  <link rel="stylesheet" href="buh.css">
</head>
<body class="bg" data-role="<?=safe($role)?>" data-buh-page="<?=safe($active)?>">
<div id="bg-layer"></div><div id="bg-overlay"></div><div class="overlay"></div>

<header class="topbar">
  <div class="brand">
    <img src="../logo.png" class="logo" alt="">
    <span>СХПК «Береговой»</span>
  </div>
  <nav class="topnav">
    <a class="link" href="../modules.php">Разделы</a>
    <?php if ($role === 'admin'): ?>
      <a class="link" href="../admin.php">Админ‑панель</a>
    <?php endif; ?>
    <a class="link" href="../logout.php">Выход</a>
  </nav>
</header>

<main class="buh-wrap">
  <section class="glass buh-shell">
    <div class="buh-head">
      <div>
        <h1 class="buh-title"><?=safe($pageTitle)?></h1>
        <p class="buh-sub">СХПК «Береговой» · Бухгалтерский модуль</p>
      </div>
      <div class="buh-who" aria-label="Текущий пользователь">
        <div class="name"><?=safe($fullName)?></div>
        <div class="role"><?=safe($roleLabel)?></div>
      </div>
    </div>

    <nav class="buh-nav" aria-label="Навигация по бухгалтерии">
      <?php foreach ($nav as $key => $item): ?>
        <a class="<?=($active===$key?'active':'')?>" href="<?=safe($item['href'])?>"><?=safe($item['label'])?></a>
      <?php endforeach; ?>
    </nav>

    <div class="buh-page">
