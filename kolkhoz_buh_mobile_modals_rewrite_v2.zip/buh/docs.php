<?php
$pageTitle = 'Бухгалтерия · Документы';
$active = 'docs';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input id="docSearch" type="search" placeholder="Поиск (контрагент, номер, тип)" aria-label="Поиск по документам">
    <select id="docDirection" data-ui="custom-select" aria-label="Направление">
      <option value="">Все</option>
      <option value="in">Входящие</option>
      <option value="out">Исходящие</option>
    </select>
    <select id="docType" data-ui="custom-select" aria-label="Тип документа">
      <option value="">Все типы</option>
      <option value="invoice">Счёт</option>
      <option value="act">Акт</option>
      <option value="waybill">Накладная</option>
      <option value="upd">УПД</option>
      <option value="other">Другое</option>
    </select>
    <select id="docStatus" data-ui="custom-select" aria-label="Статус">
      <option value="">Все статусы</option>
      <option value="draft">Черновик</option>
      <option value="received">Получено</option>
      <option value="approved">Согласовано</option>
      <option value="paid">Оплачено</option>
      <option value="closed">Закрыто</option>
      <option value="rejected">Отклонено</option>
    </select>
  </div>
  <div class="right">
    <button class="btn sm" type="button" disabled title="Скоро">Импорт</button>
    <button id="btnAddDoc" class="btn primary sm" type="button">+ Документ</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Реестр документов">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Тип</th>
        <th>Контрагент</th>
        <th>Номер</th>
        <th>Сумма</th>
        <th>Статус</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody id="tblDocsBody"></tbody>
  </table>
  <div id="docEmpty" class="buh-empty" hidden>Пока нет документов. Нажмите «+ Документ».</div>
</div>

<!-- Модалка: документ -->
<div class="modal" id="modalDoc" hidden>
  <div class="glass modal-body">
    <h2 id="docModalTitle">Документ</h2>
    <form class="form" id="formDoc" autocomplete="off">
      <input type="hidden" name="id" value="0">

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Направление
          <select name="direction" data-ui="custom-select">
            <option value="in">Входящий</option>
            <option value="out">Исходящий</option>
          </select>
        </label>
        <label style="flex:1">Тип
          <select name="doc_type" data-ui="custom-select">
            <option value="invoice">Счёт</option>
            <option value="act">Акт</option>
            <option value="waybill">Накладная</option>
            <option value="upd">УПД</option>
            <option value="other">Другое</option>
          </select>
        </label>
      </div>

      <label>Контрагент
        <select name="contractor_id" id="docContractor" data-ui="custom-select">
          <option value="">— не выбран —</option>
        </select>
      </label>

      <label>Договор
        <select name="contract_id" id="docContract" data-ui="custom-select">
          <option value="">— не выбран —</option>
        </select>
      </label>


      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Номер
          <input name="number" placeholder="№">
        </label>
        <label style="flex:1">Дата
          <input type="date" name="doc_date">
        </label>
      </div>

      <div class="row gap" style="align-items:stretch">
        <label style="flex:1">Срок оплаты
          <input type="date" name="due_date">
        </label>
        <label style="flex:1">Сумма
          <input name="amount" inputmode="decimal" placeholder="0.00">
        </label>
      </div>

      <label>Статус
        <select name="status" data-ui="custom-select">
          <option value="draft">Черновик</option>
          <option value="received">Получено</option>
          <option value="approved">Согласовано</option>
          <option value="paid">Оплачено</option>
          <option value="closed">Закрыто</option>
          <option value="rejected">Отклонено</option>
        </select>
      </label>

      <label>Комментарий
        <textarea name="comment" rows="3" placeholder="Примечание"></textarea>
      </label>

    </form>

    <div class="row gap modal-actions">
      <button class="btn primary" type="submit" form="formDoc">Сохранить</button>
      <button class="btn" type="button" data-close>Отмена</button>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
