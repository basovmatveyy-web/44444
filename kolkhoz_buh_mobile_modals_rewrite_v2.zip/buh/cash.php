<?php
$pageTitle = 'Бухгалтерия · Касса';
$active = 'cash';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input type="search" placeholder="Поиск по кассе (основание, контрагент, №)" aria-label="Поиск по кассе">
    <select data-ui="select" aria-label="Тип операции">
      <option value="">Все операции</option>
      <option value="in">Приход</option>
      <option value="out">Расход</option>
    </select>
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Экспорт</a>
    <button class="btn primary sm" type="button" disabled title="Скоро">+ Операция</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Кассовые операции">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Тип</th>
        <th>Основание</th>
        <th>Контрагент</th>
        <th>Сумма</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Дата">—</td>
        <td data-label="Тип">—</td>
        <td data-label="Основание">—</td>
        <td data-label="Контрагент">—</td>
        <td data-label="Сумма">—</td>
        <td data-label="Действия">—</td>
      </tr>
    </tbody>
  </table>
  <div class="buh-empty">Здесь будет кассовая книга: приход/расход, печать, сверка с остатком.</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
