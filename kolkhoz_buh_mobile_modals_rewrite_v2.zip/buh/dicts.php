<?php
$pageTitle = 'Бухгалтерия · Справочники';
$active = 'dicts';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <select data-ui="select" aria-label="Справочник">
      <option value="dds">Статьи ДДС</option>
      <option value="doc_types">Виды документов</option>
      <option value="cost_centers">Центры затрат</option>
      <option value="departments">Подразделения</option>
    </select>
    <input type="search" placeholder="Поиск по справочнику" aria-label="Поиск по справочнику">
  </div>
  <div class="right">
    <button class="btn primary sm" type="button" disabled title="Скоро">+ Добавить</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Справочники">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Код</th>
        <th>Название</th>
        <th>Статус</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Код">—</td>
        <td data-label="Название">—</td>
        <td data-label="Статус"><span class="pill">Пусто</span></td>
        <td data-label="Действия">—</td>
      </tr>
    </tbody>
  </table>
  <div class="buh-empty">Здесь будут справочники (статьи ДДС, типы документов, подразделения, центры затрат).</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
