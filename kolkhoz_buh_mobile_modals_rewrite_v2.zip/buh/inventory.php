<?php
$pageTitle = 'Бухгалтерия · Склад/МТР';
$active = 'inventory';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <input type="search" placeholder="Поиск (номенклатура, артикул, документ)" aria-label="Поиск по складу">
    <select data-ui="select" aria-label="Склад">
      <option value="">Все склады</option>
      <option value="main">Основной</option>
      <option value="fuel">ГСМ</option>
    </select>
  </div>
  <div class="right">
    <a class="btn sm" href="reports.php">Экспорт</a>
    <button class="btn primary sm" type="button" disabled title="Скоро">+ Поступление</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Складские движения">
  <table class="buh-table">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Документ</th>
        <th>Номенклатура</th>
        <th>Приход</th>
        <th>Расход</th>
        <th>Остаток</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Дата">—</td>
        <td data-label="Документ">—</td>
        <td data-label="Номенклатура">—</td>
        <td data-label="Приход">—</td>
        <td data-label="Расход">—</td>
        <td data-label="Остаток">—</td>
      </tr>
    </tbody>
  </table>
  <div class="buh-empty">Здесь будет учёт МТР/склад: поступления, списания, инвентаризации, остатки.</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
