<?php
$pageTitle = 'Бухгалтерия · Отчёты';
$active = 'reports';
require_once __DIR__ . '/_header.php';
?>

<div class="buh-toolbar">
  <div class="left">
    <select id="repType" data-ui="custom-select" aria-label="Отчёт">
      <option value="pay_reg">Реестр платежей</option>
      <option value="docs_reg">Реестр документов</option>
      <option value="contractors_debt">К оплате по контрагентам</option>
      <option value="contracts_reg">Реестр договоров</option>
    </select>
    <input id="repFrom" type="date" aria-label="Дата с" style="max-width:180px">
    <input id="repTo" type="date" aria-label="Дата по" style="max-width:180px">
  </div>
  <div class="right">
    <button id="btnRepPreview" class="btn sm" type="button">Сформировать</button>
    <button id="btnRepExport" class="btn primary sm" type="button">Экспорт CSV</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Результат отчёта">
  <table class="buh-table">
    <thead id="repHead"></thead>
    <tbody id="repBody"></tbody>
  </table>
  <div id="repEmpty" class="buh-empty" hidden>Нет данных по выбранным фильтрам.</div>
  <div class="buh-empty muted sm" style="border-top:1px solid rgba(255,255,255,.06)">
    Экспорт — CSV (открывается в Excel/Google Sheets). PDF/Excel‑шаблоны добавим далее.
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
