<?php
$pageTitle = 'Бухгалтерия · Настройки';
$active = 'settings';
require_once __DIR__ . '/_header.php';

$role = (string)($_SESSION['user']['role'] ?? 'user');
if ($role !== 'admin') {
  http_response_code(403);
  ?>
  <div class="buh-toolbar">
    <div class="left"><span class="pill">Доступ только для админа</span></div>
  </div>
  <div class="buh-empty">Раздел настроек доступен только роли <b>Админ</b>.</div>
  <?php
  require_once __DIR__ . '/_footer.php';
  exit;
}
?>

<div class="buh-toolbar">
  <div class="left">
    <span class="pill">Настройки модуля</span>
  </div>
  <div class="right">
    <button class="btn primary sm" type="button" disabled title="Скоро">Сохранить</button>
  </div>
</div>

<div class="buh-table-wrap" role="region" aria-label="Настройки бухгалтерии">
  <table class="buh-table">
    <thead>
      <tr><th>Раздел</th><th>Параметр</th><th>Значение</th></tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Раздел">Организация</td>
        <td data-label="Параметр">Реквизиты</td>
        <td data-label="Значение">—</td>
      </tr>
      <tr>
        <td data-label="Раздел">Документы</td>
        <td data-label="Параметр">Нумерация</td>
        <td data-label="Значение">—</td>
      </tr>
      <tr>
        <td data-label="Раздел">Права</td>
        <td data-label="Параметр">Роли</td>
        <td data-label="Значение">Админ / Бухгалтер</td>
      </tr>
    </tbody>
  </table>
  <div class="buh-empty">Сюда вынесем настройки и справочники (по мере наполнения).</div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
