<?php
/**
 * buh_db.php — миграции/хелперы Бухгалтерии.
 * Таблицы создаются автоматически при первом обращении к API.
 */

declare(strict_types=1);

if (!function_exists('buh_migrate')) {
  function buh_migrate(PDO $pdo): void {
    // На некоторых хостингах нет прав на CREATE/ALTER — в таком случае просто молча игнорируем,
    // но API вернёт нормальную ошибку при первом INSERT/SELECT.
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_contractors (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        type VARCHAR(20) NOT NULL DEFAULT 'supplier',
        name VARCHAR(255) NOT NULL,
        inn VARCHAR(20) NULL,
        kpp VARCHAR(20) NULL,
        ogrn VARCHAR(20) NULL,
        bank_name VARCHAR(255) NULL,
        bik VARCHAR(20) NULL,
        account VARCHAR(34) NULL,
        corr_account VARCHAR(34) NULL,
        phone VARCHAR(50) NULL,
        email VARCHAR(120) NULL,
        address VARCHAR(255) NULL,
        comment TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_type (type),
        KEY idx_name (name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_contracts (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        contractor_id INT UNSIGNED NOT NULL,
        number VARCHAR(80) NOT NULL,
        doc_date DATE NULL,
        subject VARCHAR(255) NULL,
        amount DECIMAL(14,2) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        start_date DATE NULL,
        end_date DATE NULL,
        comment TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_contractor (contractor_id),
        KEY idx_status (status),
        CONSTRAINT fk_buh_contracts_contractor FOREIGN KEY (contractor_id)
          REFERENCES buh_contractors(id) ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_docs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        direction VARCHAR(10) NOT NULL DEFAULT 'in',
        doc_type VARCHAR(20) NOT NULL DEFAULT 'invoice',
        contractor_id INT UNSIGNED NULL,
        contract_id INT UNSIGNED NULL,
        number VARCHAR(80) NULL,
        doc_date DATE NULL,
        due_date DATE NULL,
        amount DECIMAL(14,2) NULL,
        vat_amount DECIMAL(14,2) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'draft',
        comment TEXT NULL,
        file_path VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_dir (direction),
        KEY idx_type (doc_type),
        KEY idx_status (status),
        KEY idx_contractor (contractor_id),
        KEY idx_contract (contract_id),
        CONSTRAINT fk_buh_docs_contractor FOREIGN KEY (contractor_id)
          REFERENCES buh_contractors(id) ON DELETE SET NULL,
        CONSTRAINT fk_buh_docs_contract FOREIGN KEY (contract_id)
          REFERENCES buh_contracts(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_payments (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        pay_date DATE NULL,
        contractor_id INT UNSIGNED NULL,
        contract_id INT UNSIGNED NULL,
        doc_id INT UNSIGNED NULL,
        amount DECIMAL(14,2) NOT NULL DEFAULT 0,
        purpose VARCHAR(255) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'draft',
        method VARCHAR(10) NOT NULL DEFAULT 'bank',
        created_by INT UNSIGNED NULL,
        approved_by INT UNSIGNED NULL,
        approved_at DATETIME NULL,
        paid_at DATETIME NULL,
        dds_id INT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_status (status),
        KEY idx_pay_date (pay_date),
        KEY idx_contractor (contractor_id),
        KEY idx_contract (contract_id),
        KEY idx_doc (doc_id),
        KEY idx_dds (dds_id),
        CONSTRAINT fk_buh_payments_contractor FOREIGN KEY (contractor_id)
          REFERENCES buh_contractors(id) ON DELETE SET NULL,
        CONSTRAINT fk_buh_payments_contract FOREIGN KEY (contract_id)
          REFERENCES buh_contracts(id) ON DELETE SET NULL,
        CONSTRAINT fk_buh_payments_doc FOREIGN KEY (doc_id)
          REFERENCES buh_docs(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      // Справочник статей ДДС
      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_dds (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        kind VARCHAR(5) NOT NULL DEFAULT 'out',
        name VARCHAR(255) NOT NULL,
        comment TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_kind (kind),
        KEY idx_name (name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      // Таблица "лента" под аудит/журнал.
      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_feed (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        entity VARCHAR(20) NOT NULL,
        entity_id INT UNSIGNED NOT NULL,
        title VARCHAR(255) NOT NULL,
        status VARCHAR(30) NULL,
        user_id INT UNSIGNED NULL,
        PRIMARY KEY (id),
        KEY idx_entity (entity, entity_id),
        KEY idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      // Мягкие до-миграции (на случай если таблица была создана до добавления новых колонок)
      try { $pdo->exec("ALTER TABLE buh_payments ADD COLUMN approved_at DATETIME NULL"); } catch (Throwable $e) {}
      try { $pdo->exec("ALTER TABLE buh_payments ADD COLUMN dds_id INT UNSIGNED NULL"); } catch (Throwable $e) {}
      try { $pdo->exec("ALTER TABLE buh_payments ADD INDEX idx_dds (dds_id)"); } catch (Throwable $e) {}

      // Статьи ДДС (справочник)
      $pdo->exec("CREATE TABLE IF NOT EXISTS buh_dds (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        kind VARCHAR(5) NOT NULL DEFAULT 'out',
        name VARCHAR(255) NOT NULL,
        comment TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_kind (kind),
        KEY idx_name (name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");


    } catch (Throwable $e) {
      // ignore
    }
  }
}

if (!function_exists('buh_feed_add')) {
  function buh_feed_add(PDO $pdo, string $entity, int $entityId, string $title, ?string $status = null, ?int $userId = null): void {
    try {
      $st = $pdo->prepare("INSERT INTO buh_feed(entity, entity_id, title, status, user_id) VALUES(?,?,?,?,?)");
      $st->execute([$entity, $entityId, $title, $status, $userId]);
    } catch (Throwable $e) {
      // ignore
    }
  }
}
